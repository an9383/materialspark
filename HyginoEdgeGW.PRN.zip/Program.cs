﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hygino.ProfileUtil;

namespace HyginoEdgeGW.PRN
{
    static class Program
    {
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool createdNew;
            Mutex dup = new Mutex(true, "HyginoEdgeGW.PRN", out createdNew); //Mutex생성
            if (createdNew)
            {
                //CommonConstants.DEF_FolderName = Application.StartupPath;
                if (!Directory.Exists(CommonConstants.DEF_FolderName))
                    Directory.CreateDirectory(CommonConstants.DEF_FolderName);
                if (CommonConstants.Profiles[CommonConstants.PROFILE_SYS] == null)
                    CommonConstants.Profiles[CommonConstants.PROFILE_SYS] = (Profile)new Ini(CommonConstants.SYS_FileName);
                Console.WriteLine("SYS_FileName = {0}", CommonConstants.SYS_FileName);
                Program.LoadBaseSetting();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FormMain());
            }
            else // 프로그램이 중복 실행된 경우 
            {
                MessageBox.Show("이미 프로그램이 실행중입니다.", "HyginoPrintApp.PRT");
            }
        }

        internal static void LoadBaseSetting()
        {
            CommonConstants.SIP = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "SIP", "127.0.0.1");
            CommonConstants.SPORT = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "SPORT", 8181);
            CommonConstants.PID = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PID", "");
            //CommonConstants.PNM = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "AppId", "");
            //CommonConstants.PPT = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "AppId", "");
            CommonConstants.PRT = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PRT", "");
            CommonConstants.PCNT = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PCNT", "");
            CommonConstants.PMETHOD = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PMETHOD", "");
            CommonConstants.PRINTER1 = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PRINTER1", "");
            CommonConstants.PRINTER2 = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "PRINTER2", "");
            CommonConstants.LABEL1 = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "LABEL1", "노란색");
            CommonConstants.LABEL2 = CommonConstants.Profiles[CommonConstants.PROFILE_SYS].GetValue("PRN", "LABEL2", "파란색");
        }
    }
}
