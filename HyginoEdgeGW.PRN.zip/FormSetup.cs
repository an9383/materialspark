﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HyginoEdgeGW.PRN
{
    public partial class FormSetup : Form
    {
        public FormSetup()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (txtAppId.Text == null || txtAppId.Text == "")
            {
                MessageBox.Show("Application ID를 입력해 주세요.");
                return;
            }

            if (txtServerIp.Text == null || txtServerIp.Text == "")
            {
                MessageBox.Show("서버IP를 입력해 주세요.");
                return;
            }

            if (txtServerPort.Text == null || txtServerPort.Text == "")
            {
                MessageBox.Show("서버Port를 입력해 주세요.");
                return;
            }

            if (cbPrintMethod.Text == null || cbPrintMethod.Text == "")
            {
                MessageBox.Show("프린트 방법을 선택해 주세요.");
                return;
            }

            if (cbPrinterCnt.Text == null || cbPrinterCnt.Text == "")
            {
                MessageBox.Show("라벨 프린터 수를 선택해 주세요.");
                return;
            }

            if (cbPrinter1.Text == null || cbPrinter1.Text == "")
            {
                MessageBox.Show("첫 번째 프린터를 선택해 주세요.");
                return;
            }

            if ((cbPrinter2.Text == null || cbPrinter2.Text == "") && cbPrinterCnt.Text != "1")
            {
                MessageBox.Show("두 번째 프린터을  선택해 주세요.");
                return;
            }

            if (txtLabel1.Text == null || txtLabel1.Text == "")
            {
                MessageBox.Show("첫 번째 프린터로 출력하실 라벨을 입력해 주세요.");
                return;
            }

            if ((txtLabel2.Text == null || txtLabel2.Text == "") && cbPrinterCnt.Text != "1")
            {
                MessageBox.Show("두 번째 프린터로 출력하실 라벨을 입력해 주세요.");
                return;
            }

            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "PID", (object)txtAppId.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "SIP", (object)txtServerIp.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "SPORT", (object)txtServerPort.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "PMETHOD", (object)cbPrintMethod.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "PCNT", (object)cbPrinterCnt.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "PRINTER1", (object)cbPrinter1.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "PRINTER2", (object)cbPrinter2.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "LABEL1", (object)txtLabel1.Text);
            CommonConstants.Profiles[CommonConstants.PROFILE_SYS].SetValue("PRN", "LABEL2", (object)txtLabel2.Text);

            Program.LoadBaseSetting();

            this.Close();
        }

        private void FormSetup_Load(object sender, EventArgs e)
        {
            cbPrintMethod.Items.Add("엑셀");
            cbPrintMethod.Items.Add("코드");

            cbPrinterCnt.Items.Add("1");
            cbPrinterCnt.Items.Add("2");

            // 무조건 첫번째 프린터를 가져온다
            for (int j = 0; j < System.Drawing.Printing.PrinterSettings.InstalledPrinters.Count; j++)
            {
                cbPrinter1.Items.Add(System.Drawing.Printing.PrinterSettings.InstalledPrinters[j]);
                cbPrinter2.Items.Add(System.Drawing.Printing.PrinterSettings.InstalledPrinters[j]);
            }

            // 저장되어있던 값 불러오기
            txtAppId.Text = CommonConstants.PID;
            txtServerIp.Text = CommonConstants.SIP;
            txtServerPort.Text = CommonConstants.SPORT.ToString();
            cbPrintMethod.Text = CommonConstants.PMETHOD;
            cbPrinterCnt.Text = CommonConstants.PCNT;
            cbPrinter1.Text = CommonConstants.PRINTER1;
            cbPrinter2.Text = CommonConstants.PRINTER2;
            txtLabel1.Text = CommonConstants.LABEL1;
            txtLabel2.Text = CommonConstants.LABEL2;
        }
    }
}
