﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.Sockets;
using Newtonsoft.Json;
using System.Drawing.Printing;
//using System.Printing;
using System.Threading;
using HyginoEdgeGW.PRN.IfPrinter;
using Excel = Microsoft.Office.Interop.Excel;
//using CrystalDecisions.CrystalReports.Engine;

namespace HyginoEdgeGW.PRN
{
    public partial class FormMain : Form
    {
        String wsIp = "127.0.0.1";
        public static String temp = "";
        int wsPort = 8181;
        FormLog dlgLog;
        wsServer ws;
        Printer printer;
        bool bExit = false;

        public FormMain()
        {
            InitializeComponent();
            wsIp = CommonConstants.SIP;
            wsPort = CommonConstants.SPORT;

            this.WindowState = FormWindowState.Minimized;
            this.ShowInTaskbar = false;
            this.Visible = false;
            this.notifyIcon.Visible = true;//Tray 보이기 속성
            notifyIcon.ContextMenuStrip = contextMenuStrip;//Tray(notifyicon)와 contextMenuStrip연결
            if (ws != null)
            {
                MessageBox.Show("Hy-Tech Printer is already started ");
                //Console.WriteLine("웹소켓 서버가 이미 시작되었습니다.");
                PrnLog.LogWrite("웹소켓 서버가 이미 시작되었습니다.");
                Application.Exit();
            }

        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            if (ws == null)
            {
                //MessageBox.Show("Hi-Tech Printer Start");
                //Console.WriteLine("웹소켓 서버를 시작합니다.");
                PrnLog.LogWrite("웹소켓 서버를 시작합니다.");
                ws = new wsServer(wsIp, wsPort, dlgLog);

            }

            //App 기본정보 설정
            if (CommonConstants.PID == null || "".Equals(CommonConstants.PID))
            {
                Form formSetup = new FormSetup();
                formSetup.ShowDialog();
                Application.Restart();
            }
        }

        private void ToolStripMenuItemStart_Click(object sender, EventArgs e)
        {
            if (ws == null)
            {
                MessageBox.Show("Hy-Tech Printer Start");
                //Console.WriteLine("웹소켓 서버를 시작합니다.");
                PrnLog.LogWrite("웹소켓 서버를 시작합니다.");
                ws = new wsServer(wsIp, wsPort, dlgLog);
                // 엔터를 입력하면 앱이 종료됩니다.
                Console.ReadLine();
            }
            else
            {
                MessageBox.Show("Hy-Tech Printer is already started ");
                //Console.WriteLine("웹소켓 서버가 이미 시작되었습니다.");
                PrnLog.LogWrite("웹소켓 서버가 이미 시작되었습니다.");
            }
        }

        private void toolStripMenuItemReStart_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void toolStripMenuItemSetting_Click(object sender, EventArgs e)
        {
            foreach (Form frm in Application.OpenForms)
            {
                //Console.WriteLine("Form Name = {0}", frm.Name);
                PrnLog.LogWrite("Form Name = " + frm.Name);
                if (frm.Name == "FormSetup")
                {
                    frm.Activate();
                    return;
                }
            }

            FormSetup dlgSetup = new FormSetup();
            dlgSetup.ShowDialog();
        }

        private void ToolStripMenuItemAbout_Click(object sender, EventArgs e)
        {
            foreach (Form frm in Application.OpenForms)
            {
                //Console.WriteLine("Form Name = {0}", frm.Name);
                PrnLog.LogWrite("Form Name = "+ frm.Name);
                if (frm.Name == "FormAbout")
                {
                    frm.Activate();
                    return;
                }
            }

            FormAbout dlgAbout = new FormAbout();
            dlgAbout.ShowDialog();
        }

        private void ToolStripMenuItemLog_Click(object sender, EventArgs e)
        {
            foreach (Form frm in Application.OpenForms)
            {
                //Console.WriteLine("Form Name = {0}", frm.Name);
                PrnLog.LogWrite("Form Name = " + frm.Name);
                if (frm.Name == "FormLog")
                {
                    frm.Activate();
                    return;
                }
            }

            dlgLog = new FormLog();
            if (ws != null)
            {
                ws.setFormLog(dlgLog);
                //Console.WriteLine("웹로그창을 오픈 합니다.");
                PrnLog.LogWrite("웹로그창을 오픈 합니다.");
                //MessageBox.Show("웹로그창을 오픈 합니다.");
            }

            dlgLog.ShowDialog();
        }

        private void ToolStripMenuItemExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hy-Tech Printer Exit");
            bExit = true;
            Application.Exit();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!bExit)
            {
                e.Cancel = true; // 종료 이벤트 취소
                this.Visible = false; // 폼을 표시하지 않는다.
            }
        }

        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }
    }

    class wsServer
    {

        // 초기화 시 입력 받는 값들.
        public string addr = "";
        public int port = 0;
        public FormLog dlgLog;
        public Printer lblPrinter;

        private delegate void SetTextSafeDelegate(string text);

        // 읽기에 사용되는 값들.
        public static NetworkStream clientStream = null;
        byte[] readBuffer = new byte[500000];



        // 동작에 사용되는 멤버 변수들.
        TcpListener listner = null;
        TcpClient client = null;
        //IAsyncResult asyncResult = null;

        // 생성자를 만들어 주도록 합니다.
        public wsServer(string _addr, int _port, FormLog _dlgLog)
        {

            // 입력 받은 값들을 저장해 줍니다.
            addr = _addr;
            port = _port;
            dlgLog = _dlgLog;


            try
            {
                listner = new TcpListener(IPAddress.Parse(addr), port);
                //Console.WriteLine("addr : " + _addr + " , port : " + port);
                PrnLog.LogWrite("addr : " + _addr + " , port : " + port);
                listner.Start();
                Console.WriteLine("웹소켓 서버를 오픈하도록 합니다.");
                PrnLog.LogWrite("웹소켓 서버를 오픈하도록 합니다.");

                //asyncResult = listner.BeginAcceptTcpClient(OnServerConnect, null);
                listner.BeginAcceptTcpClient(OnServerConnect, null);
                //Console.WriteLine("클라이언트와의 접속을 기다립니다.");
                PrnLog.LogWrite("클라이언트와의 접속을 기다립니다.");
            }
            catch
            {
                MessageBox.Show("ip 주소 에러");
                //Properties.Settings.Default.IPAddress = Form1.temp;
                //FormSetting dlgSetting = new FormSetting();
                //dlgSetting.ShowDialog();
            }

        }

        // 서버를 중지 합니다.
        public void setFormLog(FormLog _dlgLog)
        {
            dlgLog = _dlgLog;
        }


        // 서버의 접속이 들어 왔을 때 처리하는 메소드 입니다.
        void OnServerConnect(IAsyncResult ar)
        {
            Array.Clear(readBuffer, 0x0, 500000);

            client = listner.EndAcceptTcpClient(ar);
            //Console.WriteLine("한 클라이언트가 접속했습니다.");
            PrnLog.LogWrite("한 클라이언트가 접속했습니다.");

            // 클라이언트의 접속을 다시 대기.
            listner.BeginAcceptTcpClient(OnServerConnect, null);

            // 현재의 클라이언트로 부터 데이터를 받아 옵니다.
            clientStream = client.GetStream();
            clientStream.BeginRead(readBuffer, 0, readBuffer.Length, onAcceptReader, null);

        }


        // 클라이언트의 데이터를 읽어 오는 메소드 입니다.
        void onAcceptReader(IAsyncResult ar)
        {
            //Array.Clear(readBuffer, 0x0, 500000);
            // 받은 데이터의 길이를 확인합니다.
            int receiveLength = clientStream.EndRead(ar);


            // 받은 데이터가 없는 경우는 접속이 끊어진 경우 입니다.
            if (receiveLength <= 0)
            {
                //Console.WriteLine("접속이 끊어졌습니다.");
                PrnLog.LogWrite("접속이 끊어졌습니다.");
                return;
            }

            // 받은 메시지를 출력합니다.
            string newMessage = Encoding.UTF8.GetString(readBuffer, 0, receiveLength);
            //Console.WriteLine(readBuffer.ToString());

            //Console.WriteLine(
            //    string.Format("받은 메시지:\n{0}", newMessage)
            //);

            PrnLog.LogWrite(string.Format("받은 메시지:\n{0}", newMessage));

            //tb_receive.AppendText("SendCmd Socket connected to {0} " + sender.RemoteEndPoint.ToString() + " \r\n");
            //dlgLog.textLog_print(newMessage);
            SetText(string.Format("받은 메시지:\n{0}", newMessage));

            // 첫 3문자가 GET으로 시작하지 않는 경우, 잘못된 접속이므로 종료합니다.
            if (!Regex.IsMatch(newMessage, "^GET"))
            {
                //Console.WriteLine("잘못된 접속 입니다.");
                PrnLog.LogWrite("잘못된 접속 입니다.");
                client.Close();
                return;
            }

            // 클라이언트로 응답을 돌려 줍니다.
            const string eol = "\r\n"; // HTTP/1.1 defines the sequence CR LF as the end-of-line marker

            // 보낼 메시지.
            string resMessage = "HTTP/1.1 101 Switching Protocols" + eol
                + "Connection: Upgrade" + eol
                + "Upgrade: websocket" + eol
                + "Sec-WebSocket-Accept: " + Convert.ToBase64String(
                    System.Security.Cryptography.SHA1.Create().ComputeHash(
                        Encoding.UTF8.GetBytes(
                            new Regex("Sec-WebSocket-Key: (.*)").Match(newMessage).Groups[1].Value.Trim() + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
                        )
                    )
                ) + eol
                + eol
                ;

            // 보낸 메시지를 출력해 봅니다.
            //Console.WriteLine(
            //    string.Format("보낸 메시지:\n{0}", resMessage)
            //);

            PrnLog.LogWrite(string.Format("보낸 메시지:\n{0}", resMessage));
            //SetText(string.Format("보낸 메시지:\n{0}", resMessage));

            // 메시지를 보내 줍니다.
            Byte[] response = Encoding.ASCII.GetBytes(resMessage);
            clientStream.Write(response, 0, response.Length);

            // 에코 메시지 받기 시작.
            clientStream.BeginRead(readBuffer, 0, readBuffer.Length, onEchoReader, null);

        }

        private void SetTextSafe(string text)
        {
            if (dlgLog != null)
            {
                //Console.WriteLine("로그창 오픈 되었습니다.");

                if (dlgLog.InvokeRequired)
                {
                    SetTextSafeDelegate del = new SetTextSafeDelegate(SetTextSafe);
                    dlgLog.Invoke(del, new object[] { text });
                }
                else
                {
                    dlgLog.textLog_print(text);
                }
            }


        }

        private void SetText(String data)
        {
            SetTextSafe(data);
        }

        // 에코 메시지를 받아 오는 부분 입니다.
        void onEchoReader(IAsyncResult ar)
        {
            int receiveLength = 0;
            try
            {
                // 받은 데이터의 길이를 확인합니다.
                receiveLength = clientStream.EndRead(ar);
            }
            catch (Exception e)
            {
                return;
            }
            // 받은 데이터가 6인 경우는 종료 상태 일 뿐이므로, 종료 데이터를 보내고 우리도 접속을 종료합니다.
            if (receiveLength == 6)
            {
                //Console.WriteLine("접속 해제 요청이 와 접속을 종료합니다.");
                PrnLog.LogWrite("접속 해제 요청이 와 접속을 종료합니다.");
                client.Close();
                return;
            }

            // 받은 데이터가 없는 경우는 접속이 끊어진 경우 입니다.
            if (receiveLength <= 0)
            {
                //Console.WriteLine("접속이 끊어졌습니다.");
                PrnLog.LogWrite("접속이 끊어졌습니다.");
                return;
            }

            // 새로고침시 쓰레기 값이 들어온 것 입니다.
            if (receiveLength <= 10)
            {
                //Console.WriteLine("새로고침을 하였습니다.");
                PrnLog.LogWrite("새로고침을 하였습니다.");
                return;
            }

            BitArray maskingCheck = new BitArray(new byte[] { readBuffer[1] });
            int msglen = readBuffer[1] - 128;
            int offset = 2;
            int receivedSize = (int)readBuffer[1];
            if (msglen == 126)  //길이 126 이상의 경우
            {
                msglen = BitConverter.ToInt16(new byte[] { readBuffer[3], readBuffer[2] }, 0);

                offset = 4;
            }
            byte[] mask = new byte[4] { readBuffer[offset], readBuffer[offset + 1], readBuffer[offset + 2], readBuffer[offset + 3] };
            offset += 4;
            if (maskingCheck.Get(0))
            {
                //Console.WriteLine("마스킹 되어 있습니다.");
                PrnLog.LogWrite("마스킹 되어 있습니다.");
                SetText(string.Format("마스킹 되어 있습니다."));
                receivedSize -= 128;            // 마스킹으로 인해 추가된 값을 빼 줍니다.
            }
            else
            {
                //Console.WriteLine("마스킹 되어 있지 않습니다.");
                PrnLog.LogWrite("마스킹 되어 있지 않습니다.");
                SetText(string.Format("마스킹 되어 있지 않습니다."));
            }


            // 문자열을 길이를 파악합니다.
            //Console.WriteLine("onEchoReader받은 데이터 길이 비트 : {0}", receivedSize);
            PrnLog.LogWrite("onEchoReader받은 데이터 길이 비트 : "+ receivedSize);
            SetText(string.Format("onEchoReader받은 데이터 길이 비트 : {0}", receivedSize));
            //Console.WriteLine("onEchoReader받은 데이터 길이 : {0}", receiveLength);
            PrnLog.LogWrite("onEchoReader받은 데이터 길이 : " + receiveLength);
            SetText(string.Format("onEchoReader받은 데이터 길이: {0}", receiveLength));
            PrnLog.LogWrite("onEchoReader받은 시간 : " + DateTime.Now);
            SetText(string.Format("onEchoReader받은 시간: {0}", DateTime.Now));


            // 받은 메시지를 디코딩해 줍니다.
            byte[] decodedByte = new byte[msglen];
            for (int _i = 0; _i < msglen; _i++)
            {

                int curIndex = _i + 6;
                decodedByte[_i] = (byte)(readBuffer[offset + _i] ^ mask[_i % 4]);
            }

            // 받은 메시지를 출력합니다.
            //string newMessage = Encoding.UTF8.GetString( readBuffer, 6, receiveLength - 6 );
            string newMessage = Encoding.UTF8.GetString(decodedByte);
            //string newMessage = Encoding.UTF8.GetBytes(readBuffer, 6, receiveLength - 6);
            //string newMessage2 = Encoding.UTF8.GetString(decodedByte, 0, receivedSize);

            //System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();

            //System.Text.Decoder utf8Decode = encoder.GetDecoder();



            //byte[] todecode_byte = Convert.FromBase64String(newMessage2);

            //int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);

            //char[] decoded_char = new char[charCount];

            //utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);

            //string result = new String(decoded_char);

            //Console.WriteLine(
            //    string.Format("onEchoReader받은 메시지:{0}", result)
            //);

            //Console.WriteLine(
            //    string.Format("onEchoReader받은 메시지:{0}", newMessage)
            //);
            PrnLog.LogWrite(string.Format("onEchoReader받은 메시지:{0}", newMessage));
            SetText(string.Format("onEchoReader받은 메시지:{0}", newMessage));

            //Printer.PrintText(newMessage);
            labelPrinter(newMessage);

            string sendSource = "이 문자열이 보이면 성공!";
            if (!Printer.isSame)
            {
                sendSource = "matrlFalse";
            }

            byte[] sendMessage = Encoding.UTF8.GetBytes(sendSource);

            // 보낼 메시지를 만들어 줍니다.
            List<byte> sendByteList = new List<byte>();

            // 첫 데이터의 정보를 만들어 추가합니다.
            BitArray firstInfor = new BitArray(
                new bool[]{
                    true                // FIN
                    , false             // RSV1
                    , false             // RSV2
                    , false             // RSV3

                    // opcode (0x01: 텍스트)
                    , false
                    , false
                    , false
                    , true

                }
            );
            byte[] inforByte = new byte[1];
            firstInfor.CopyTo(inforByte, 0);
            sendByteList.Add(inforByte[0]);

            // 문자열의 길이를 추가합니다.
            sendByteList.Add((byte)sendMessage.Length);

            // 실제 데이터를 추가합니다.
            sendByteList.AddRange(sendMessage);

            // 보낸 메시지를 출력해 봅니다.
            //Console.WriteLine(string.Format("보낸 메시지:\n{0}", sendSource));
            PrnLog.LogWrite(string.Format("보낸 메시지:\n{0}", sendSource));

            SetText(string.Format("보낸 메시지:\n{0}", sendSource));

            // 받은 메시지를 그대로 보내 줍니다.
            clientStream.Write(sendByteList.ToArray(), 0, sendByteList.Count);
            //Console.WriteLine(string.Format("보낸 메시지 길이:{0}", sendByteList.Count));
            PrnLog.LogWrite(string.Format("보낸 메시지 길이:{0}", sendByteList.Count));

            SetText(string.Format("보낸 메시지 길이:{0}", sendByteList.Count));

            // 또 다음 메시지를 받을 수 있도록 대기 합니다.
            clientStream.BeginRead(readBuffer, 0, readBuffer.Length, onEchoReader, null);
        }

        //MES별 바코드 라벨 프린터 처리
        private void labelPrinter(String data)
        {
            Printer.PrintText(data);
        }

    }

    public static class PrnLog
    {

        public static void LogWrite(string strMsg)
        {
            try
            {
                string strCheckFolder = "";
                string strFileName = "";
                //현재 EXE 파일가 위치 하고 있는 폴더를 가져옴.
                //string strLocal = Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf("\\"));
                //Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + strMsg);
                //로그 폴더가 없으면 생성 

                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + strMsg);

                strCheckFolder = "C:\\HYPRN\\PRNLOG" + "\\" + DateTime.Now.ToString("yyyyMM");

                if (!System.IO.Directory.Exists(strCheckFolder))
                {
                    System.IO.Directory.CreateDirectory(strCheckFolder);
                }

                strFileName = strCheckFolder + "\\" + DateTime.Now.ToString("yyyyMMdd") + ".txt";

                System.IO.StreamWriter FileWriter = new System.IO.StreamWriter(strFileName, true);
                FileWriter.Write(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + strMsg + "\r\n");
                FileWriter.Flush();
                FileWriter.Close();
            }
            catch
            {
                //return false;
            }

            //return true;
        }
    }

    public class Printer
    {
        static public bool isSame = true; //올바른 라벨 출력 여부

        public Printer()
        {
            //
            // TODO: 여기에 생성자 논리를 추가합니다.
            //
        }

        [DllImport("winspool.drv")]
        private static extern bool OpenPrinter(
         [In] string pPrinterName,
         [In, Out] ref System.IntPtr hPrinter,
         [In] byte[] pDefault
         );

        [DllImport("winspool.drv")]
        private static extern bool ClosePrinter(
         [In, Out] System.IntPtr hPrinter
         );

        [DllImport("winspool.drv")]
        unsafe private static extern bool WritePrinter(
         [In] System.IntPtr hPrinter,
         [In, Out] byte[] pBuf,
         [In] int cbBug,
         ref int pcWritten
         );

        [DllImport("winspool.drv")]
        unsafe private static extern bool WritePrinter(
         [In] System.IntPtr hPrinter,
         [In, Out] string pBuf,
         [In] int cbBug,
         ref int pcWritten
         );

        [DllImport("winspool.drv")]
        unsafe private static extern int StartDocPrinter(
         [In] System.IntPtr hPrinter,
         [In] int nLevel,
         [In] ref DOC_INFO_1 pDocInfo
         );

        [DllImport("winspool.drv")]
        unsafe private static extern bool StartPagePrinter(
         [In] System.IntPtr hPrinter
         );

        [DllImport("winspool.drv")]
        unsafe private static extern bool EndPagePrinter(
         [In] System.IntPtr hPrinter
         );

        [DllImport("winspool.drv")]
        unsafe private static extern bool EndDocPrinter(
         [In] System.IntPtr hPrinter
         );
        [DllImport("winspool.drv")]
        public static extern bool SetDefaultPrinter(string name);

        [DllImport("user32.dll", SetLastError = true)]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);


        public static void PrintText(string strPrintText)
        {
            int result = 0;

            PrintString printString;
            printString = JsonConvert.DeserializeObject<PrintString>(strPrintText);

            PrintDocument PD = new PrintDocument();
            string originPrinter = PD.PrinterSettings.PrinterName;
            //string printername = CommonConstants.PNM;
            //string paperPath = CommonConstants.PPT;

            System.IntPtr handle = System.IntPtr.Zero;
            if (PrinterSettings.InstalledPrinters.Count == 0)
            {
                throw new Exception("시스템에 프린터가 없음");
            }
            printString.printType = CommonConstants.PMETHOD;

            if (printString.printNo == "1") { printString.printerName = CommonConstants.PRINTER1; }
            else if (printString.printNo == "2") { printString.printerName = CommonConstants.PRINTER2; }

            // MTP1 & MTP2 - 잘못된 자재 출력 시 예외처리
            if (printString.printNo == "1" && (printString.company == "MTP1" || printString.company == "MTP2")) { isSame = ("NC".Equals(CommonConstants.LABEL1)) ? true : false; }
            else if (printString.printNo == "2" && (printString.company == "MTP1" || printString.company == "MTP2")) { isSame = ("AL".Equals(CommonConstants.LABEL2)) ? true : false; }

            if (isSame)
            {
                if (printString.printerName != null)
                {
                    if (printString.printerName.Contains("TOSHIBA")) { printString.printerCode = "T"; }
                    else if (printString.printerName.Contains("GT800")) { printString.printerCode = "G"; }

                    SetDefaultPrinter(printString.printerName);
                }

                PrnLog.LogWrite("printString.company >>>" + printString.company);

                if (printString.company == "Komotek") { Komotek komotek = new Komotek(); result = komotek.PrintKomotek(printString); }
                else if (printString.company == "MTP1") { Materialspark1 materialpark1 = new Materialspark1(); result = materialpark1.PrintMTP1(printString); }
                else if (printString.company == "MTP2") { Materialspark2 materialpark2 = new Materialspark2(); result = materialpark2.PrintMTP2(printString); }
                else if (printString.company == "MTP3") { Materialspark1 materialpark1 = new Materialspark1(); result = materialpark1.PrintMTP1_Before(printString); } //생산실적(Tray)_코드_기존버전 (23.08.01 13:00 이후 사용 X)
                else if (printString.company == "SLD") { Soulbrain soulbrain = new Soulbrain(); result = soulbrain.PrintSLD(printString); }
                else if (printString.company == "Daerim") { DaerimAuto daerimeAuto = new DaerimAuto(); result = daerimeAuto.PrintDaerim(printString); }

                PrnLog.LogWrite("failCount >>>" + result);

                //기본 프린터 원상복구
                SetDefaultPrinter(originPrinter);
            }
        }

        public Excel.Application CreateExcel()
        {
            Excel.Application oXL = null;
            oXL = new Excel.Application()
            {
                Visible = false,
                DisplayAlerts = false
            };
            return oXL;
        }

        public void DeleteExcel(Excel.Application oXL)
        {
            //엑셀 프로그램 종료
            uint processId = 0;

            GetWindowThreadProcessId(new IntPtr(oXL.Hwnd), out processId);
            oXL.Quit();
            if (processId != 0)
            {
                System.Diagnostics.Process excelProcess = System.Diagnostics.Process.GetProcessById((int)processId);
                excelProcess.CloseMainWindow();
                excelProcess.Refresh();
                excelProcess.Kill();
            }
        }

        public string bmpToCommand(string url)
        {
            int[,] colorArr = new int[160, 160];
            int[] bit2Arr = new int[25600];
            string result = "";
            Bitmap bm_img = new Bitmap(url);
            for (int y = 0; y < bm_img.Height; y++)
            {
                for (int x = 0; x < bm_img.Width; x++)
                {
                    Color pixelColor = bm_img.GetPixel(x, y);
                    Color newColor = Color.FromArgb(pixelColor.R, 0, 0);

                    if (pixelColor.G <= 100 && pixelColor.B <= 100 && pixelColor.R <= 100)
                    {
                        colorArr[x, y] = 1;
                        bit2Arr[(y * bm_img.Height) + x] = 1;
                    }
                    else
                    {
                        colorArr[x, y] = 0;
                        bit2Arr[(y * bm_img.Height) + x] = 0;
                    }
                }
            }
            for (int x = 0; x < (bm_img.Width * bm_img.Height) / 4; x++)
            {
                int temp = 0;
                for (int y = 0; y < 4; y++)
                {
                    temp += bit2Arr[(x * 4) + y] * (int)Math.Pow(2, (3 - y));
                }

                switch (temp)
                {
                    case 0: result += "0"; break;
                    case 1: result += "1"; break;
                    case 2: result += "2"; break;
                    case 3: result += "3"; break;
                    case 4: result += "4"; break;
                    case 5: result += "5"; break;
                    case 6: result += "6"; break;
                    case 7: result += "7"; break;
                    case 8: result += "8"; break;
                    case 9: result += "9"; break;
                    case 10: result += ":"; break;
                    case 11: result += ";"; break;
                    case 12: result += "<"; break;
                    case 13: result += "="; break;
                    case 14: result += ">"; break;
                    case 15: result += "?"; break;
                }
            }
            return result;
        }

        public struct DOC_INFO_1
        {
            public string pDocName;
            public string pOutputFile;
            public string pDatatype;
        }

        public static string ChangeSerialNum(int serialNum)
        {
            if (serialNum < 10) { return "000" + serialNum.ToString(); }
            else if (serialNum >= 10 && serialNum < 100) { return "00" + serialNum.ToString(); }
            else if (serialNum >= 100 && serialNum < 1000) { return "0" + serialNum.ToString(); }
            else if (serialNum >= 1000) { return serialNum.ToString(); }
            else { return "ERROR"; }
        }

    }

    public class PrintString
    {
        //public string printNo;
        //public string printNm;
        public int printCnt;
        public int printLalCnt;
        public string paperSize;
        public int printOrder;
        public string company;
        public string printType;
        public string printNo;
        public int moveX;
        public int moveY;

        public string[][] column;
        public string[][] data;
        public string printerName;
        public string printerCode;
    }

}
