﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.IO;

namespace HyginoEdgeGW.PRN
{
    class RawPrinterHelper
    {
        // Structure and API declarions:
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public class DOCINFOA
        {
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDocName;
            [MarshalAs(UnmanagedType.LPStr)]
            public string pOutputFile;
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDataType;
        }
        [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);

        [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool ClosePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);

        [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndDocPrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

        [DllImport("winspool.drv", EntryPoint = "FlushPrinter", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool FlushPrinter(IntPtr hPrinter, IntPtr pBuf, Int32 cbBuf, out Int32 pcWritten, Int32 cSleep);


        // SendBytesToPrinter()
        // When the function is given a printer name and an unmanaged array
        // of bytes, the function sends those bytes to the print queue.
        // Returns true on success, false on failure.
        public static bool SendBytesToPrinter(string szPrinterName, IntPtr pBytes, Int32 dwCount)
        {
            bool bSuccess = false; // Assume failure unless you specifically succeed.
            bool aSuccess = false; // Assume failure unless you specifically succeed.
            bool cSuccess = false; // Assume failure unless you specifically succeed.
            bool dSuccess = false; // Assume failure unless you specifically succeed.
            bool fSuccess = false; // Assume failure unless you specifically succeed.

            try
            {
                Int32 dwError = 0, dwWritten = 0;
                IntPtr hPrinter = new IntPtr(0);
                DOCINFOA di = new DOCINFOA();
                

                di.pDocName = "My C#.NET RAW Document";
                //di.pDataType = "RAW";
                di.pDataType = "RAW";

                // Open the printer.
                if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero))
                {
                    // Start a document.
                    if (StartDocPrinter(hPrinter, 1, di))
                    {
                        // Start a page.
                        if (StartPagePrinter(hPrinter))
                        {
                            // Write your bytes.
                            bSuccess = WritePrinter(hPrinter, pBytes, dwCount, out dwWritten);
                            //fSuccess = FlushPrinter(hPrinter, pBytes, dwCount, out dwWritten, 2);
                            aSuccess = EndPagePrinter(hPrinter);
                        }
                        cSuccess = EndDocPrinter(hPrinter);
                    }
                    //dSuccess = ClosePrinter(hPrinter);
                }

                PrnLog.LogWrite("hPrinter >>>" + hPrinter + "  pBytes >>>" + pBytes + "  dwCount >>>" + dwCount + "  dwWritten >>>" + dwWritten);
                PrnLog.LogWrite("is NonError ???  " + (dwCount == dwWritten));


                // If you did not succeed, GetLastError may give more information
                // about why not.
                if (bSuccess == false)
                {
                    dwError = Marshal.GetLastWin32Error();
                }
            }
            catch(Exception e)
            {
                bSuccess = false;
                PrnLog.LogWrite("SendBytesToPrinter Exception Error >>>" + e.Message.ToString());
            } 
            finally
            {
                PrnLog.LogWrite("SendBytesToPrinter finally >>>" + bSuccess);
            }
            return bSuccess;
        }

        public static bool SendFileToPrinter(string szPrinterName, string szFileName)
        {
            // Open the file.
            FileStream fs = new FileStream(szFileName, FileMode.Open);
            // Create a BinaryReader on the file.
            BinaryReader br = new BinaryReader(fs);
            // Dim an array of bytes big enough to hold the file's contents.
            Byte[] bytes = new Byte[fs.Length];
            bool bSuccess = false;
            // Your unmanaged pointer.
            IntPtr pUnmanagedBytes = new IntPtr(0);
            int nLength;

            nLength = Convert.ToInt32(fs.Length);
            // Read the contents of the file into the array.
            bytes = br.ReadBytes(nLength);
            // Allocate some unmanaged memory for those bytes.
            pUnmanagedBytes = Marshal.AllocCoTaskMem(nLength);
            // Copy the managed byte array into the unmanaged array.
            Marshal.Copy(bytes, 0, pUnmanagedBytes, nLength);
            // Send the unmanaged bytes to the printer.
            bSuccess = SendBytesToPrinter(szPrinterName, pUnmanagedBytes, nLength);
            // Free the unmanaged memory that you allocated earlier.
            Marshal.FreeCoTaskMem(pUnmanagedBytes);
            return bSuccess;
        }

        public static bool SendStringToPrinter(string szPrinterName, string szString, string encodingType)
        {
            IntPtr pBytes;
            Int32 dwCount;
            bool isSuccess;

            // How many characters are in the string?
            // Fix from Nicholas Piasecki:
            // dwCount = szString.Length;
            PrnLog.LogWrite("SendBytesToPrinter >>> szPrinterName = " + szPrinterName + " ,encodingType = " + encodingType + " ,szString = " + szString);

            dwCount = (szString.Length + 1) * Marshal.SystemMaxDBCSCharSize;

            // Assume that the printer is expecting ANSI text, and then convert
            // the string to ANSI text.
            //pBytes = Marshal.StringToCoTaskMemAnsi(szString);

            if (encodingType == "utf-8") { pBytes = NativeUtf8FromString(szString); }
            else if (encodingType == "euc-kr") { pBytes = EuckrEncoding(szString); }
            else { return false; }
            
            //PrnLog.LogWrite("euc-kr >>>> " + EuckrEncoding(szString));
            //PrnLog.LogWrite("ANSI >>>> " + Marshal.StringToCoTaskMemAnsi(szString));
            //PrnLog.LogWrite("utf-8 >>>> " + NativeUtf8FromString(szString));

            // Send the converted ANSI string to the printer.
            isSuccess = SendBytesToPrinter(szPrinterName, pBytes, dwCount);
            //Console.WriteLine("SendBytesToPrinter >>> dwCount = {0},SystemMaxDBCSCharSize = {1}", dwCount, Marshal.SystemMaxDBCSCharSize);
            PrnLog.LogWrite("SendBytesToPrinter >>> dwCount = "+ dwCount +" ,SystemMaxDBCSCharSize = "+ Marshal.SystemMaxDBCSCharSize);
            Marshal.FreeCoTaskMem(pBytes);
            return isSuccess;
        }
        public unsafe static string PtrToStringUtf8(IntPtr ptr, int length)
        {
            if (ptr == IntPtr.Zero)
                return null;

            byte[] buff = new byte[length];
            Marshal.Copy(ptr, buff, 0, length);
            return System.Text.UTF8Encoding.UTF8.GetString(buff);
        }

        public static IntPtr NativeUtf8FromString(string managedString)
        {
            int len = Encoding.UTF8.GetByteCount(managedString);
            byte[] buffer = new byte[len + 1];
            Encoding.UTF8.GetBytes(managedString, 0, managedString.Length, buffer, 0);
            IntPtr nativeUtf8 = Marshal.AllocHGlobal(buffer.Length);
            Marshal.Copy(buffer, 0, nativeUtf8, buffer.Length);
            //PrnLog.LogWrite("NativeUtf8FromString >>> managedString = " + managedString.Length + " ,buffer = " + buffer.Length);
            return nativeUtf8;
        }

        public static IntPtr EuckrEncoding(string data)
        {
            System.Text.Encoding euckr = System.Text.Encoding.GetEncoding(51949);
            byte[] euckrBytes = euckr.GetBytes(data);
            string urlEncodingText = "";
            foreach (byte b in euckrBytes)
            {
                string addText = Convert.ToString(b, 16);
                urlEncodingText = urlEncodingText + "%" + addText;
            }

            IntPtr nativeUtf8 = Marshal.AllocHGlobal(euckrBytes.Length);
            Marshal.Copy(euckrBytes, 0, nativeUtf8, euckrBytes.Length);
            return nativeUtf8;
        }

    }

}
