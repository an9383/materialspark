﻿
namespace HyginoEdgeGW.PRN
{
    partial class FormSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSetup));
            this.label1 = new System.Windows.Forms.Label();
            this.cbPrinterCnt = new System.Windows.Forms.ComboBox();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtServerIp = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLabel2 = new System.Windows.Forms.TextBox();
            this.txtLabel1 = new System.Windows.Forms.TextBox();
            this.cbPrinter2 = new System.Windows.Forms.ComboBox();
            this.cbPrinter1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtServerPort = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbPrintMethod = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(20, 220);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Printer Count";
            // 
            // cbPrinterCnt
            // 
            this.cbPrinterCnt.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbPrinterCnt.FormattingEnabled = true;
            this.cbPrinterCnt.Location = new System.Drawing.Point(150, 215);
            this.cbPrinterCnt.Name = "cbPrinterCnt";
            this.cbPrinterCnt.Size = new System.Drawing.Size(330, 32);
            this.cbPrinterCnt.TabIndex = 18;
            // 
            // txtAppId
            // 
            this.txtAppId.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtAppId.Location = new System.Drawing.Point(150, 15);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.Size = new System.Drawing.Size(330, 35);
            this.txtAppId.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(20, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 19);
            this.label7.TabIndex = 31;
            this.label7.Text = "Server Port";
            // 
            // txtServerIp
            // 
            this.txtServerIp.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtServerIp.Location = new System.Drawing.Point(150, 65);
            this.txtServerIp.Name = "txtServerIp";
            this.txtServerIp.Size = new System.Drawing.Size(330, 35);
            this.txtServerIp.TabIndex = 30;
            this.txtServerIp.Text = "127.0.0.1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(20, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 19);
            this.label6.TabIndex = 29;
            this.label6.Text = "Server IP";
            // 
            // txtLabel2
            // 
            this.txtLabel2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtLabel2.Location = new System.Drawing.Point(150, 415);
            this.txtLabel2.Name = "txtLabel2";
            this.txtLabel2.Size = new System.Drawing.Size(330, 35);
            this.txtLabel2.TabIndex = 28;
            this.txtLabel2.Text = "파란색";
            // 
            // txtLabel1
            // 
            this.txtLabel1.Font = new System.Drawing.Font("굴림", 18F);
            this.txtLabel1.Location = new System.Drawing.Point(150, 365);
            this.txtLabel1.Name = "txtLabel1";
            this.txtLabel1.Size = new System.Drawing.Size(330, 35);
            this.txtLabel1.TabIndex = 27;
            this.txtLabel1.Text = "노란색";
            // 
            // cbPrinter2
            // 
            this.cbPrinter2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbPrinter2.FormattingEnabled = true;
            this.cbPrinter2.Location = new System.Drawing.Point(150, 315);
            this.cbPrinter2.Name = "cbPrinter2";
            this.cbPrinter2.Size = new System.Drawing.Size(330, 32);
            this.cbPrinter2.TabIndex = 26;
            // 
            // cbPrinter1
            // 
            this.cbPrinter1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbPrinter1.FormattingEnabled = true;
            this.cbPrinter1.Location = new System.Drawing.Point(150, 265);
            this.cbPrinter1.Name = "cbPrinter1";
            this.cbPrinter1.Size = new System.Drawing.Size(330, 32);
            this.cbPrinter1.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(20, 420);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 19);
            this.label5.TabIndex = 24;
            this.label5.Text = "Printer2 Label";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(20, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 19);
            this.label4.TabIndex = 23;
            this.label4.Text = "Printer1 Label";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(20, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "Printer2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(20, 270);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 19);
            this.label2.TabIndex = 21;
            this.label2.Text = "Printer1";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(422, 471);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(77, 37);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "설정";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(20, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 19);
            this.label8.TabIndex = 33;
            this.label8.Text = "Print Method";
            // 
            // txtServerPort
            // 
            this.txtServerPort.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtServerPort.Location = new System.Drawing.Point(150, 115);
            this.txtServerPort.Name = "txtServerPort";
            this.txtServerPort.Size = new System.Drawing.Size(330, 35);
            this.txtServerPort.TabIndex = 36;
            this.txtServerPort.Text = "8181";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(20, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 19);
            this.label9.TabIndex = 35;
            this.label9.Text = "App ID";
            // 
            // cbPrintMethod
            // 
            this.cbPrintMethod.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cbPrintMethod.FormattingEnabled = true;
            this.cbPrintMethod.Location = new System.Drawing.Point(150, 165);
            this.cbPrintMethod.Name = "cbPrintMethod";
            this.cbPrintMethod.Size = new System.Drawing.Size(330, 32);
            this.cbPrintMethod.TabIndex = 37;
            // 
            // FormSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 520);
            this.Controls.Add(this.cbPrintMethod);
            this.Controls.Add(this.txtServerPort);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtAppId);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtServerIp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtLabel2);
            this.Controls.Add(this.txtLabel1);
            this.Controls.Add(this.cbPrinter2);
            this.Controls.Add(this.cbPrinter1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.cbPrinterCnt);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormSetup";
            this.Text = "HyginoEdgeGW.PRN Setup";
            this.Load += new System.EventHandler(this.FormSetup_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbPrinterCnt;
        private System.Windows.Forms.TextBox txtAppId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtServerIp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLabel2;
        private System.Windows.Forms.TextBox txtLabel1;
        private System.Windows.Forms.ComboBox cbPrinter2;
        private System.Windows.Forms.ComboBox cbPrinter1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtServerPort;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbPrintMethod;
    }
}