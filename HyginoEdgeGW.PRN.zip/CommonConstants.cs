﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hygino.ProfileUtil;

namespace HyginoEdgeGW.PRN
{
    class CommonConstants
    {
        public static string DEF_FolderName = "C:\\HYPRN";

        public static string SIP = "127.0.0.1";     // 서버IP
        public static int SPORT = 9998;             // 서버PORT
        public static string PID = "";              // 프린터 업체명 komotek, soulbrain, mits...
        //public static string PNM = "";              // 프린터명 
        //public static string PPT = "";              // 프린터 용지
        public static string PRT = "";              // 프린트유형 (CD:코드, EXCEL:엑셀, CRYSTAL:크리스탈, 4:...)
        public static string PCNT = "";             // 프린터수
        public static string LABEL1 = "";
        public static string LABEL2 = "";
        public static string PRINTER1 = "";
        public static string PRINTER2 = "";
        public static string PMETHOD = "";

        public static string SettingIni = "Settings.prn.ini";
        public static int PROFILE_SYS = 0;

        private static Profile[] _mProfiles = new Profile[3];
        private static string _sYS_FileName = string.Empty;

        public static Profile[] Profiles
        {
            get => CommonConstants._mProfiles;
            set => CommonConstants._mProfiles = value;
        }

        public static string SYS_FileName
        {
            get
            {
                if (string.IsNullOrWhiteSpace(CommonConstants._sYS_FileName))
                    CommonConstants._sYS_FileName = CommonConstants.DEF_FolderName + "\\" + SettingIni;
                return CommonConstants._sYS_FileName;
            }
        }
    }
}
