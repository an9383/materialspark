﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HyginoEdgeGW.PRN
{
    public partial class FormLog : Form
    {
        public FormLog()
        {
            InitializeComponent();
        }

        public void textLog_print(String data)
        {
            textLog.AppendText(data + " \r\n");
        }

        private void textLog_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
