﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace HyginoEdgeGW.PRN.IfPrinter
{
    class Materialspark2 : Printer
    {
        PrintString pS = new PrintString();

        //코드 생성자
        public int PrintMTP2(PrintString ps)
        {
            int result = 0;
            if (ps.printType == "코드")
            {
                switch (ps.paperSize)
                {
                    case "productionTray":
                        result = ProductionTray_Code(ps); break;
                    default:
                        result = 0; break;
                }
            }
            else if (ps.printType == "엑셀")
            {
                switch (ps.paperSize)
                {
                    case "productionTray":
                        result = ProductionTray_Excel(ps); break;
                    case "materialLabel":
                        result = MaterialLabel_Excel(ps); break;
                    default:
                        result = 0; break;
                }
            }

            return result;
        }

        //생산실적(Tray)_코드
        private int ProductionTray_Code(PrintString ps)
        {
            bool result = true;
            int failCount = 0;

            for (int i = 0; i < ps.printCnt; i++)
            {
                FormLog rm = new FormLog();
                string cmd = "{AX;+000,+000,+00|}";
                cmd += "{AY;+10,0|}";
                cmd += "{D0520,0980,0500|}";
                cmd += "{C|}";

                //이미지
                string imgCommand = bmpToCommand(Directory.GetCurrentDirectory() + @"\MTP2\Image\" + ps.data[i][10] + ".bmp");
                cmd += "{SG;0505,0188,0160,0160,0," + imgCommand + "|}";

                //행
                cmd += "{LC;0010,0040,0970,0490,1,5|}";
                cmd += "{LC;0010,0110,0710,0110,0,5|}";
                cmd += "{LC;0010,0180,0970,0180,0,5|}";
                cmd += "{LC;0010,0250,0500,0250,0,5|}";
                cmd += "{LC;0010,0320,0500,0320,0,5|}";
                cmd += "{LC;0010,0390,0970,0390,0,5|}";
                cmd += "{LC;0710,0040,0710,0390,0,5|}";
                cmd += "{LC;0270,0390,0270,0490,0,5|}";
                cmd += "{LC;0710,0250,0970,0250,0,5|}";
                cmd += "{LC;0500,0180,0500,0390,0,5|}";

                cmd += "{PV23;0560,0150,0130,0130,01,0,00,B=" + ps.data[i][8] + "|}";

                cmd += "{PV23;0020,0090,0040,0040,01,0,00,B=제품번호 : " + ps.data[i][0] + "|}";
                cmd += "{PV23;0020,0160,0040,0040,01,0,00,B=Lot Number(총수량: " + ps.data[i][1] + ")|}";
                cmd += "{PV23;0020,0230,0034,0034,01,0,00,B=" + ps.data[i][2] + "|}";
                cmd += "{PV23;0020,0300,0034,0034,01,0,00,B=" + ps.data[i][3] + "|}";
                cmd += "{PV23;0020,0370,0034,0034,01,0,00,B=" + ps.data[i][4] + "|}";
                cmd += "{PV23;0290,0460,0034,0034,01,0,00,B=BOX NO : " + ps.data[i][5] + "|}";
                cmd += "{XB01;0740,0065,9,2,01,0,0060,+0000000001,000,1,00|}";
                cmd += "{RB01;" + ps.data[i][6] + "|}";
                cmd += "{PV23;0740,0230,0040,0040,01,0,00,B=APPROVED|}";
                cmd += "{PV23;0740,0330,0040,0040,01,0,00,B=" + ps.data[i][9] + "|}";
                cmd += "{PV23;0800,0380,0040,0040,01,0,00,B=(" + ps.data[i][7] + ")|}";
                cmd += "{XB02;0070,0410,9,3,01,0,0070,+0000000001,000,0,00|}";
                cmd += "{RB02;" + ps.data[i][5] + "|}";
                cmd += "{XS;I,0001,0002C5101|}";

                Console.WriteLine(string.Format(">>>>>>>>>>>>>>>> 보낸 명령어 :{0},{1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), cmd));

                result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
                if (result == false)
                {
                    failCount++;
                }
            }
            return failCount;
        }

        //생산실적(Tray)_엑셀
        private int ProductionTray_Excel(PrintString ps)
        {
            //Excel Setting
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;

            int failCount = 0;

            for (int i = 0; i < ps.printCnt; i++)
            {
                try
                {

                    Excel.Application oXL = CreateExcel();
                    oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\MTP2\Paper\" + ps.paperSize + ".xlsm"));
                    oSheet = (Excel.Worksheet)oWB.ActiveSheet;

                    //사진 읽기
                    Excel.Pictures p = oSheet.Pictures(Type.Missing) as Excel.Pictures;
                    Excel.Picture pic = null;
                    //사진 위치설정
                    pic = p.Insert(Filename: Directory.GetCurrentDirectory() + @"\MTP2\Image\" + ps.data[i][9] + ".bmp", Type.Missing);
                    pic.ShapeRange.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoCTrue;
                    pic.ShapeRange.Width = 55;
                    pic.ShapeRange.Height = 54;
                    pic.Left = 123;
                    pic.Top = 42;

                    oSheet.Cells[1, 1] = "제품번호 : " + ps.data[i][0];
                    oSheet.Cells[2, 1] = "Lot Number(총수량 : " + ps.data[i][1] + ")";
                    oSheet.Cells[3, 1] = ps.data[i][2];
                    oSheet.Cells[4, 1] = ps.data[i][3];
                    oSheet.Cells[6, 1] = ps.data[i][4];
                    oSheet.Cells[8, 1] = "*" + ps.data[i][5] + "*";
                    oSheet.Cells[1, 4] = "*" + ps.data[i][6] + "*";
                    oSheet.Cells[2, 4] = ps.data[i][6];
                    oSheet.Cells[5, 4] = ps.data[i][8];
                    oSheet.Cells[7, 4] = "(" + ps.data[i][7] + ")";
                    oSheet.Cells[8, 2] = "BOX NO : " + ps.data[i][5];

                    oSheet.Application.Run("PRINT_LABEL");

                    DeleteExcel(oXL);
                }
                catch (Exception theException)
                {
                    String errorMessage;
                    errorMessage = "Error: ";
                    errorMessage = String.Concat(errorMessage, theException.Message);
                    errorMessage = String.Concat(errorMessage, " Line: ");
                    errorMessage = String.Concat(errorMessage, theException.Source);
                    failCount++;
                }
            }
            return failCount;
        }

        // 자재 라벨_엑셀
        private int MaterialLabel_Excel(PrintString ps)
        {
            //Excel Setting
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;

            int failCount = 0;

            for (int i = 0; i < ps.printCnt; i++)
            {
                try
                {

                    //프린터 설정
                    if (ps.printNo.Equals("0"))
                    {
                        if (ps.data[i][5].Equals("P2")) { SetDefaultPrinter(CommonConstants.PRINTER1); }
                        else { SetDefaultPrinter(CommonConstants.PRINTER2); }
                    }

                    //엑셀 파일
                    Excel.Application oXL = CreateExcel();
                    oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\MTP2\Paper\" + ps.paperSize + ".xlsm"));
                    oSheet = (Excel.Worksheet)oWB.ActiveSheet;

                    //값 넣기
                    oSheet.Cells[1, 2] = ps.data[i][0];
                    oSheet.Cells[2, 2] = ps.data[i][1];
                    oSheet.Cells[3, 1] = "*" + ps.data[i][2] + "*";
                    oSheet.Cells[3, 4] = ps.data[i][2];
                    oSheet.Cells[1, 4] = ps.data[i][3];
                    oSheet.Cells[2, 5] = ps.data[i][4];

                    oSheet.Application.Run("PRINT_LABEL");

                    DeleteExcel(oXL);
                }
                catch (Exception theException)
                {
                    String errorMessage;
                    errorMessage = "Error: ";
                    errorMessage = String.Concat(errorMessage, theException.Message);
                    errorMessage = String.Concat(errorMessage, " Line: ");
                    errorMessage = String.Concat(errorMessage, theException.Source);
                    failCount++;
                }
            }
            return failCount;
        }

    }
}
