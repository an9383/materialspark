﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;


namespace HyginoEdgeGW.PRN.IfPrinter
{
	class Komotek : Printer
	{
		PrintString pS = new PrintString();

		public int PrintKomotek(PrintString ps)
		{
			int result = 0;

			if (ps.printType == "코드")
			{
				switch (ps.paperSize)
				{
					case "locationAdm":
						result = LocationAdm_Code(ps); break;
					case "productionSlip":
						result = ProductionSlip_Code(ps); break;
					case "partLarge":
						result = PartLarge_Code(ps); break;
					case "partSmall":
						result = PartSmall_Code(ps); break;
					case "itemLarge":
						result = ItemLarge_Code(ps); break;
					case "itemSmall":
						result = ItemSmall_Code(ps); break;
					case "purchaseOrderLarge":
						result = PurchaseOrderLarge_Code(ps); break;
					case "purchaseOrderSmall":
						result = PurchaseOrderSmall_Code(ps); break;
					case "individualLarge":
						result = IndividualLarge_Code(ps); break;
					case "individualSmall":
						result = IndividualSmall_Code(ps); break;
					default:
						result = 0; break;
				}
			}
			else if (ps.printType == "엑셀")
			{
				switch (ps.paperSize)
				{
					case "smallProduct":
						result = SmallProduct_Excel(ps); break;
					default:
						result = 0; break;
				}
			}
			return result;
		}

		//창고정보관리
		private int LocationAdm_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				string cmd = "^XA";
				cmd += "^PRD";
				cmd += "^SEE:UHANGUL.DAT^FS";
				cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
				if (i + 1 == ps.printCnt)
				{
					for (int j = 0; j < ps.printOrder; j++)
					{
						string x = "";

						if (j == 0) { x = "177"; }
						else if (j == 1) { x = "360"; }
						else { x = "545"; }

						cmd += "^FO" + x + ",85^A1N,30,30^FD" + ps.data[i * 3 + j][0] + "^FS";
						cmd += "^FO" + x + ",115^BQN,2,5^FD123" + ps.data[i * 3 + j][1] + "^FS";
					}
				}
				else
				{
					cmd += "^FO177,85^A1N,30,30^FD" + ps.data[i * 3][0] + "^FS";
					cmd += "^FO177,115^BQN,2,5^FD123" + ps.data[i * 3][1] + "^FS";
					cmd += "^FO360,85^A1N,30,30^FD" + ps.data[i * 3 + 1][0] + "^FS";
					cmd += "^FO360,115^BQN,2,5^FD123" + ps.data[i * 3 + 1][1] + "^FS";
					cmd += "^FO545,85^A1N,30,30^FD" + ps.data[i * 3 + 2][0] + "^FS";
					cmd += "^FO545,115^BQN,2,5^FD123" + ps.data[i * 3 + 2][1] + "^FS";
				}
				cmd += "^XZ";

				result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
				if (result == false)
				{
					failCount++;

				}
			}

			return failCount;
		}

		//생산전표
		private int ProductionSlip_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				string cmd = "{AX;+000,+000,+00|}";
				cmd += "{AY;+10,0|}";
				cmd += "{D0175,0900,0145|}";
				cmd += "{C|}";

				if (i + 1 == ps.printCnt)
				{
					for (int j = 0; j < ps.printOrder; j++)
					{
						string a = "", b = "", c = "", d = "";

						if (j == 0) { a = "0150"; b = "0130"; c = "0125"; d = "0010"; }

						else if (j == 1) { a = "0380"; b = "0360"; c = "0355"; d = "0240"; }

						else if (j == 2) { a = "0610"; b = "0590"; c = "0585"; d = "0470"; }

						else if (j == 3) { a = "0840"; b = "0820"; c = "0815"; d = "0700"; }

						cmd += "{PV01;" + a + ",0015,0023,0023,01,0,11,B|}";
						cmd += "{RV01;" + ps.data[i * 4][0] + "|}";
						cmd += "{PV02;" + b + ",0015,0023,0023,01,0,11,B|}";
						cmd += "{RV02;" + ps.data[i * 4][1] + "|}";
						cmd += "{XB01;" + d + ",0020,T,L,03,A,0,M2|}";
						cmd += "{RB01;" + ps.data[i * 4][3] + "|}";
					}
				}
				else
				{

					cmd += "{PV01;0150,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV01;" + ps.data[i * 4][0] + "|}";
					cmd += "{PV02;0130,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV02;" + ps.data[i * 4][1] + "|}";
					//cmd += "{PV03;0125,0015,0023,0023,01,0,11,B|}";
					//cmd += "{RV03;" + ps.data[i * 4][2] + "|}";
					cmd += "{XB01;0010,0005,T,L,03,A,0,M2|}";
					cmd += "{RB01;" + ps.data[i * 4][3] + "|}";

					cmd += "{PV01;0380,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV01;" + ps.data[i * 4 + 1][0] + "|}";
					cmd += "{PV02;0360,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV02;" + ps.data[i * 4 + 1][1] + "|}";
					//cmd += "{PV03;0355,0015,0023,0023,01,0,11,B|}";
					//cmd += "{RV03;" + ps.data[i * 4 + 1][2] + "|}";
					cmd += "{XB02;0240,0005,T,L,03,A,0,M2|}";
					cmd += "{RB02;" + ps.data[i * 4 + 1][3] + "|}";

					cmd += "{PV01;0610,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV01;" + ps.data[i * 4 + 2][0] + "|}";
					cmd += "{PV02;0590,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV02;" + ps.data[i * 4 + 2][1] + "|}";
					//cmd += "{PV03;0585,0015,0023,0023,01,0,11,B|}";
					//cmd += "{RV03;" + ps.data[i * 4 + 2][2] + "|}";
					cmd += "{XB03;0470,0005,T,L,03,A,0,M2|}";
					cmd += "{RB03;" + ps.data[i * 4 + 2][3] + "|}";

					cmd += "{PV01;0840,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV01;" + ps.data[i * 4 + 3][0] + "|}";
					cmd += "{PV02;0820,0000,0023,0023,01,0,11,B|}";
					cmd += "{RV02;" + ps.data[i * 4 + 3][1] + "|}";
					//cmd += "{PV03;0815,0015,0023,0023,01,0,11,B|}";
					//cmd += "{RV03;" + ps.data[i * 4 + 3][2] + "|}";
					cmd += "{XB03;0700,0005,T,L,03,A,0,M2|}";
					cmd += "{RB03;" + ps.data[i * 4 + 3][3] + "|}";
				}

				cmd += "{XS;I,0001,0002C5101|}";

				result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
				if (result == false)
				{
					failCount++;

				}
			}

			return failCount;
		}

		//바코드정보관리_자재_기본
		private int PartLarge_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{D0900,1000,0900|}";
					cmd += "{C|}";
					cmd += "{LC;0060,0035,0930,0440,1,5|}";
					cmd += "{LC;0060,0105,0930,0105,0,5|}";
					cmd += "{LC;0060,0175,0930,0175,0,5|}";
					cmd += "{LC;0060,0245,0930,0245,0,5|}";
					cmd += "{LC;0060,0315,0930,0315,0,5|}";
					cmd += "{LC;0320,0035,0320,0315,0,5|}";

					cmd += "{PV01;0065,0080,0030,0030,01,0,00,B|}";
					cmd += "{RV01;CODE NO/부품위치|}";
					cmd += "{PV01;0115,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;I T E M|}";
					cmd += "{PV01;0110,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;S P E C|}";
					cmd += "{PV01;0075,0290,0035,0035,01,0,00,B|}";
					cmd += "{RV01;입고일자/수량|}";

					cmd += "{PV01;0340,0080,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][0] + "    /    " + ps.data[i][1] + "|}";
					cmd += "{PV01;0340,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][2] + "|}";
					cmd += "{PV01;0340,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][3] + "|}";
					cmd += "{PV01;0340,0300,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][4] + "    /    " + ps.data[i][5] + "|}";
					cmd += "{XB02;0230,0350,9,2,02,0,0050,+0000000000,000,1,00|}";
					cmd += "{RB02;" + ps.data[i][6] + "|}";

					cmd += "{XS;I,0001,0002C5101|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO70,10^GB200,73,3^FS";
					cmd += "^FO075,35^A1N,20,20^FDCODE NO/부품위치^FS";
					cmd += "^FO70,80^GB200,73,3^FS";
					cmd += "^FO110,105^A1N,30,30^FDI T E M^FS";
					cmd += "^FO70,150^GB200,73,3^FS";
					cmd += "^FO110,175^A1N,30,30^FDS P E C^FS";
					cmd += "^FO70,220^GB200,73,3^FS";
					cmd += "^FO85,245^A1N,25,25^FD입고일자/수량^FS";
					cmd += "^FO70,290^GB700,73,3^FS";
					if (ps.data[i][6].Length > 13)
					{
						cmd += "^FO150,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					else
					{
						cmd += "^FO250,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					cmd += "^FO267,10^GB503,73,3^FS";
					cmd += "^FO282,35^A1N,30,30^FD" + ps.data[i][0] + "    /    " + ps.data[i][1] + "^FS";
					cmd += "^FO267,80^GB503,73,3^FS";
					cmd += "^FO282,105^A1N,30,30^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO267,150^GB503,73,3^FS";
					cmd += "^FO282,175^A1N,30,30^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO267,220^GB503,73,3^FS";
					cmd += "^FO282,245^A1N,30,30^FD" + ps.data[i][4] + "    /    " + ps.data[i][5] + "^FS";
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");

					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//바코드정보관리_자재_개별
		private int PartSmall_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "{D0780,1000,0750|}";
					cmd += "{C|}";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0)
							{
								x = new string[] { "230", "200", "205" };
								cmd += "{LC;0180,0025,0365,0245,1,3|}";
								cmd += "{LC;0180,0055,0365,0055,0,3|}";
								cmd += "{LC;0180,0080,0365,0080,0,3|}";
								cmd += "{LC;0180,0110,0365,0110,0,3|}";
								cmd += "{LC;0275,0080,0275,0110,0,3|}";
							}
							else if (j == 1)
							{
								x = new string[] { "460", "430", "435" };
								cmd += "{LC;0400,0025,0585,0245,1,3|}";
								cmd += "{LC;0400,0055,0585,0055,0,3|}";
								cmd += "{LC;0400,0080,0585,0080,0,3|}";
								cmd += "{LC;0400,0110,0585,0110,0,3|}";
								cmd += "{LC;0495,0080,0495,0110,0,3|}";
							}
							else
							{
								x = new string[] { "700", "660", "665" };
								cmd += "{LC;0620,0025,0805,0245,1,3|}";
								cmd += "{LC;0620,0055,0805,0055,0,3|}";
								cmd += "{LC;0620,0080,0805,0080,0,3|}";
								cmd += "{LC;0620,0110,0805,0110,0,3|}";
								cmd += "{LC;0715,0080,0715,0110,0,3|}";
							}

							cmd += "{PV01;0" + x[0] + ",0050,0025,0025,01,0,00,B|}";
							cmd += "{RV01;CODE|}";
							cmd += "{PV01;0" + x[1] + ",0075,0025,0025,01,0,00,B|}";
							cmd += "{RV01;" + ps.data[i * 3 + j][0] + "|}";
							cmd += "{PV01;0" + x[1] + ",0105,0025,0025,01,0,00,B|}";
							cmd += "{RV01;REV   " + ps.data[i * 3 + j][1] + "|}";
							cmd += "{XB03;0" + x[2] + ",0115,T,H,04,A,0|}";
							cmd += "{RB03;" + ps.data[i * 3 + j][2] + "|}";
						}
					}
					else
					{

						//행
						cmd += "{LC;0180,0025,0365,0245,1,3|}";
						cmd += "{LC;0180,0055,0365,0055,0,3|}";
						cmd += "{LC;0180,0080,0365,0080,0,3|}";
						cmd += "{LC;0180,0110,0365,0110,0,3|}";
						cmd += "{LC;0275,0080,0275,0110,0,3|}";
						//값
						cmd += "{PV01;0230,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0200,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3][0] + "|}";
						cmd += "{PV01;0200,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3][1] + "|}";
						cmd += "{XB03;0205,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3][2] + "|}";

						//행
						cmd += "{LC;0400,0025,0585,0245,1,3|}";
						cmd += "{LC;0400,0055,0585,0055,0,3|}";
						cmd += "{LC;0400,0080,0585,0080,0,3|}";
						cmd += "{LC;0400,0110,0585,0110,0,3|}";
						cmd += "{LC;0495,0080,0495,0110,0,3|}";
						//값
						cmd += "{PV01;0460,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0430,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 1][0] + "|}";
						cmd += "{PV01;0430,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 1][1] + "|}";
						cmd += "{XB03;0435,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 1][2] + "|}";

						//행
						cmd += "{LC;0620,0025,0805,0245,1,3|}";
						cmd += "{LC;0620,0055,0805,0055,0,3|}";
						cmd += "{LC;0620,0080,0805,0080,0,3|}";
						cmd += "{LC;0620,0110,0805,0110,0,3|}";
						cmd += "{LC;0715,0080,0715,0110,0,3|}";
						//값
						cmd += "{PV01;0700,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0660,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 2][0] + "|}";
						cmd += "{PV01;0660,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 2][1] + "|}";
						cmd += "{XB03;0665,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 2][2] + "|}";
					}

					cmd += "{XS;I,0001,0002C5101|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0) { x = new string[6] { "152", "198", "165", "167", "225", "180" }; }
							else if (j == 1) { x = new string[6] { "335", "381", "348", "350", "408", "363" }; }
							else { x = new string[6] { "520", "566", "533", "535", "593", "548" }; }

							cmd += "^FO" + x[0] + ",12^GB153,192,2^FS";
							cmd += "^FO" + x[0] + ",12^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB70,25,2^FS";
							cmd += "^FO" + x[1] + ",16^A1N,20,20^FDCODE^FS";
							cmd += "^FO" + x[2] + ",38^A1N,20,20^FD" + ps.data[i * 3 + j][0] + "^FS";
							cmd += "^FO" + x[3] + ",60^A1N,20,20^FDREV^FS";
							cmd += "^FO" + x[4] + ",60^A1N,20,20^FD" + ps.data[i * 3 + j][1] + "^FS";
							cmd += "^FO" + x[5] + ",85^BQN,2,4^FD123" + ps.data[i * 3 + j][2] + "^FS";
						}
					}
					else
					{
						cmd += "^FO152,12^GB153,192,2^FS";
						cmd += "^FO152,12^GB153,25,2^FS";
						cmd += "^FO152,57^GB153,25,2^FS";
						cmd += "^FO152,57^GB70,25,2^FS";
						cmd += "^FO198,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO165,38^A1N,20,20^FD" + ps.data[i * 3][0] + "^FS";
						cmd += "^FO167,60^A1N,20,20^FDREV^FS";
						cmd += "^FO225,60^A1N,20,20^FD" + ps.data[i * 3][1] + "^FS";
						cmd += "^FO180,85^BQN,2,4^FD123" + ps.data[i * 3][2] + "^FS";

						cmd += "^FO335,12^GB153,192,2^FS";
						cmd += "^FO335,12^GB153,25,2^FS";
						cmd += "^FO335,57^GB153,25,2^FS";
						cmd += "^FO335,57^GB70,25,2^FS";
						cmd += "^FO381,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO348,38^A1N,20,20^FD" + ps.data[i * 3 + 1][0] + "^FS";
						cmd += "^FO350,60^A1N,20,20^FDREV^FS";
						cmd += "^FO408,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO363,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";

						cmd += "^FO520,12^GB153,192,2^FS";
						cmd += "^FO520,12^GB153,25,2^FS";
						cmd += "^FO520,57^GB153,25,2^FS";
						cmd += "^FO520,57^GB70,25,2^FS";
						cmd += "^FO566,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO533,38^A1N,20,20^FD" + ps.data[i * 3 + 2][0] + "^FS";
						cmd += "^FO535,60^A1N,20,20^FDREV^FS";
						cmd += "^FO593,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO548,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";
					}
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//바코드정보관리_제품_기본
		private int ItemLarge_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{D0900,1000,0900|}";
					cmd += "{C|}";
					cmd += "{LC;0060,0035,0930,0440,1,5|}";
					cmd += "{LC;0060,0105,0930,0105,0,5|}";
					cmd += "{LC;0060,0175,0930,0175,0,5|}";
					cmd += "{LC;0060,0245,0930,0245,0,5|}";
					cmd += "{LC;0060,0315,0930,0315,0,5|}";
					cmd += "{LC;0320,0035,0320,0315,0,5|}";

					cmd += "{PV01;0065,0080,0030,0030,01,0,00,B|}";
					cmd += "{RV01;CODE NO/부품위치|}";
					cmd += "{PV01;0115,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;I T E M|}";
					cmd += "{PV01;0110,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;S P E C|}";
					cmd += "{PV01;0075,0290,0035,0035,01,0,00,B|}";
					cmd += "{RV01;입고일자/수량|}";

					cmd += "{PV01;0340,0080,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][0] + "    /    " + ps.data[i][1] + "|}";
					cmd += "{PV01;0340,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][2] + "|}";
					cmd += "{PV01;0340,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][3] + "|}";
					cmd += "{PV01;0340,0300,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][4] + "    /    " + ps.data[i][5] + "|}";
					cmd += "{XB02;0230,0350,9,2,02,0,0050,+0000000000,000,1,00|}";
					cmd += "{RB02;" + ps.data[i][6] + "|}";

					cmd += "{XS;I,0001,0002C5101|}";
					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO70,10^GB200,73,3^FS";
					cmd += "^FO075,35^A1N,20,20^FDCODE NO/부품위치^FS";
					cmd += "^FO70,80^GB200,73,3^FS";
					cmd += "^FO110,105^A1N,30,30^FDI T E M^FS";
					cmd += "^FO70,150^GB200,73,3^FS";
					cmd += "^FO110,175^A1N,30,30^FDS P E C^FS";
					cmd += "^FO70,220^GB200,73,3^FS";
					cmd += "^FO85,245^A1N,25,25^FD입고일자/수량^FS";
					cmd += "^FO70,290^GB700,73,3^FS";
					if (ps.data[i][6].Length > 13)
					{
						cmd += "^FO150,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					else
					{
						cmd += "^FO250,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					cmd += "^FO267,10^GB503,73,3^FS";
					cmd += "^FO282,35^A1N,30,30^FD" + ps.data[i][0] + "    /    " + ps.data[i][1] + "^FS";
					cmd += "^FO267,80^GB503,73,3^FS";
					cmd += "^FO282,105^A1N,30,30^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO267,150^GB503,73,3^FS";
					cmd += "^FO282,175^A1N,30,30^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO267,220^GB503,73,3^FS";
					cmd += "^FO282,245^A1N,30,30^FD" + ps.data[i][4] + "    /    " + ps.data[i][5] + "^FS";
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");

					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//바코드정보관리_제품_개별
		private int ItemSmall_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "{D0780,1000,0750|}";
					cmd += "{C|}";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0)
							{
								x = new string[] { "230", "200", "205" };
								cmd += "{LC;0180,0025,0365,0245,1,3|}";
								cmd += "{LC;0180,0055,0365,0055,0,3|}";
								cmd += "{LC;0180,0080,0365,0080,0,3|}";
								cmd += "{LC;0180,0110,0365,0110,0,3|}";
								cmd += "{LC;0275,0080,0275,0110,0,3|}";
							}
							else if (j == 1)
							{
								x = new string[] { "460", "430", "435" };
								cmd += "{LC;0400,0025,0585,0245,1,3|}";
								cmd += "{LC;0400,0055,0585,0055,0,3|}";
								cmd += "{LC;0400,0080,0585,0080,0,3|}";
								cmd += "{LC;0400,0110,0585,0110,0,3|}";
								cmd += "{LC;0495,0080,0495,0110,0,3|}";
							}
							else
							{
								x = new string[] { "700", "660", "665" };
								cmd += "{LC;0620,0025,0805,0245,1,3|}";
								cmd += "{LC;0620,0055,0805,0055,0,3|}";
								cmd += "{LC;0620,0080,0805,0080,0,3|}";
								cmd += "{LC;0620,0110,0805,0110,0,3|}";
								cmd += "{LC;0715,0080,0715,0110,0,3|}";
							}

							cmd += "{PV01;0" + x[0] + ",0050,0025,0025,01,0,00,B|}";
							cmd += "{RV01;CODE|}";
							cmd += "{PV01;0" + x[1] + ",0075,0025,0025,01,0,00,B|}";
							cmd += "{RV01;" + ps.data[i * 3 + j][0] + "|}";
							cmd += "{PV01;0" + x[1] + ",0105,0025,0025,01,0,00,B|}";
							cmd += "{RV01;REV   " + ps.data[i * 3 + j][1] + "|}";
							cmd += "{XB03;0" + x[2] + ",0115,T,H,04,A,0|}";
							cmd += "{RB03;" + ps.data[i * 3 + j][2] + "|}";
						}
					}
					else
					{

						//행
						cmd += "{LC;0180,0025,0365,0245,1,3|}";
						cmd += "{LC;0180,0055,0365,0055,0,3|}";
						cmd += "{LC;0180,0080,0365,0080,0,3|}";
						cmd += "{LC;0180,0110,0365,0110,0,3|}";
						cmd += "{LC;0275,0080,0275,0110,0,3|}";
						//값
						cmd += "{PV01;0230,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0200,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3][0] + "|}";
						cmd += "{PV01;0200,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3][1] + "|}";
						cmd += "{XB03;0205,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3][2] + "|}";

						//행
						cmd += "{LC;0400,0025,0585,0245,1,3|}";
						cmd += "{LC;0400,0055,0585,0055,0,3|}";
						cmd += "{LC;0400,0080,0585,0080,0,3|}";
						cmd += "{LC;0400,0110,0585,0110,0,3|}";
						cmd += "{LC;0495,0080,0495,0110,0,3|}";
						//값
						cmd += "{PV01;0460,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0430,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 1][0] + "|}";
						cmd += "{PV01;0430,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 1][1] + "|}";
						cmd += "{XB03;0435,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 1][2] + "|}";

						//행
						cmd += "{LC;0620,0025,0805,0245,1,3|}";
						cmd += "{LC;0620,0055,0805,0055,0,3|}";
						cmd += "{LC;0620,0080,0805,0080,0,3|}";
						cmd += "{LC;0620,0110,0805,0110,0,3|}";
						cmd += "{LC;0715,0080,0715,0110,0,3|}";
						//값
						cmd += "{PV01;0700,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0660,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 2][0] + "|}";
						cmd += "{PV01;0660,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 2][1] + "|}";
						cmd += "{XB03;0665,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 2][2] + "|}";
					}

					cmd += "{XS;I,0001,0002C5101|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0) { x = new string[6] { "152", "198", "165", "167", "225", "180" }; }
							else if (j == 1) { x = new string[6] { "335", "381", "348", "350", "408", "363" }; }
							else { x = new string[6] { "520", "566", "533", "535", "593", "548" }; }

							cmd += "^FO" + x[0] + ",12^GB153,192,2^FS";
							cmd += "^FO" + x[0] + ",12^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB70,25,2^FS";
							cmd += "^FO" + x[1] + ",16^A1N,20,20^FDCODE^FS";
							cmd += "^FO" + x[2] + ",38^A1N,20,20^FD" + ps.data[i * 3 + j][0] + "^FS";
							cmd += "^FO" + x[3] + ",60^A1N,20,20^FDREV^FS";
							cmd += "^FO" + x[4] + ",60^A1N,20,20^FD" + ps.data[i * 3 + j][1] + "^FS";
							cmd += "^FO" + x[5] + ",85^BQN,2,4^FD123" + ps.data[i * 3 + j][2] + "^FS";
						}
					}
					else
					{
						cmd += "^FO152,12^GB153,192,2^FS";
						cmd += "^FO152,12^GB153,25,2^FS";
						cmd += "^FO152,57^GB153,25,2^FS";
						cmd += "^FO152,57^GB70,25,2^FS";
						cmd += "^FO198,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO165,38^A1N,20,20^FD" + ps.data[i * 3][0] + "^FS";
						cmd += "^FO167,60^A1N,20,20^FDREV^FS";
						cmd += "^FO225,60^A1N,20,20^FD" + ps.data[i * 3][1] + "^FS";
						cmd += "^FO180,85^BQN,2,4^FD123" + ps.data[i * 3][2] + "^FS";

						cmd += "^FO335,12^GB153,192,2^FS";
						cmd += "^FO335,12^GB153,25,2^FS";
						cmd += "^FO335,57^GB153,25,2^FS";
						cmd += "^FO335,57^GB70,25,2^FS";
						cmd += "^FO381,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO348,38^A1N,20,20^FD" + ps.data[i * 3 + 1][0] + "^FS";
						cmd += "^FO350,60^A1N,20,20^FDREV^FS";
						cmd += "^FO408,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO363,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";

						cmd += "^FO520,12^GB153,192,2^FS";
						cmd += "^FO520,12^GB153,25,2^FS";
						cmd += "^FO520,57^GB153,25,2^FS";
						cmd += "^FO520,57^GB70,25,2^FS";
						cmd += "^FO566,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO533,38^A1N,20,20^FD" + ps.data[i * 3 + 2][0] + "^FS";
						cmd += "^FO535,60^A1N,20,20^FDREV^FS";
						cmd += "^FO593,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO548,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";
					}
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//가입고등록_기본
		private int PurchaseOrderLarge_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{D0900,1000,0900|}";
					cmd += "{C|}";
					cmd += "{LC;0060,0035,0930,0440,1,5|}";
					cmd += "{LC;0060,0105,0930,0105,0,5|}";
					cmd += "{LC;0060,0175,0930,0175,0,5|}";
					cmd += "{LC;0060,0245,0930,0245,0,5|}";
					cmd += "{LC;0060,0315,0930,0315,0,5|}";
					cmd += "{LC;0320,0035,0320,0315,0,5|}";

					cmd += "{PV01;0065,0080,0030,0030,01,0,00,B|}";
					cmd += "{RV01;CODE NO/부품위치|}";
					cmd += "{PV01;0115,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;I T E M|}";
					cmd += "{PV01;0110,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;S P E C|}";
					cmd += "{PV01;0075,0290,0035,0035,01,0,00,B|}";
					cmd += "{RV01;입고일자/수량|}";

					cmd += "{PV01;0340,0080,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][0] + "    /    " + ps.data[i][1] + "|}";
					cmd += "{PV01;0340,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][2] + "|}";
					cmd += "{PV01;0340,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][3] + "|}";
					cmd += "{PV01;0340,0300,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][4] + "    /    " + ps.data[i][5] + "|}";
					cmd += "{XB02;0230,0350,9,2,02,0,0050,+0000000000,000,1,00|}";
					cmd += "{RB02;" + ps.data[i][6] + "|}";

					cmd += "{XS;I,0001,0002C5101|}";
					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO70,10^GB200,73,3^FS";
					cmd += "^FO075,35^A1N,20,20^FDCODE NO/부품위치^FS";
					cmd += "^FO70,80^GB200,73,3^FS";
					cmd += "^FO110,105^A1N,30,30^FDI T E M^FS";
					cmd += "^FO70,150^GB200,73,3^FS";
					cmd += "^FO110,175^A1N,30,30^FDS P E C^FS";
					cmd += "^FO70,220^GB200,73,3^FS";
					cmd += "^FO85,245^A1N,25,25^FD입고일자/수량^FS";
					cmd += "^FO70,290^GB700,73,3^FS";
					if (ps.data[i][6].Length > 13)
					{
						cmd += "^FO150,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					else
					{
						cmd += "^FO250,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					cmd += "^FO267,10^GB503,73,3^FS";
					cmd += "^FO282,35^A1N,30,30^FD" + ps.data[i][0] + "    /    " + ps.data[i][1] + "^FS";
					cmd += "^FO267,80^GB503,73,3^FS";
					cmd += "^FO282,105^A1N,30,30^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO267,150^GB503,73,3^FS";
					cmd += "^FO282,175^A1N,30,30^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO267,220^GB503,73,3^FS";
					cmd += "^FO282,245^A1N,30,30^FD" + ps.data[i][4] + "    /    " + ps.data[i][5] + "^FS";
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");

					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//가입고등록_개별
		private int PurchaseOrderSmall_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "{D0780,1000,0750|}";
					cmd += "{C|}";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0)
							{
								x = new string[] { "230", "200", "205" };
								cmd += "{LC;0180,0025,0365,0245,1,3|}";
								cmd += "{LC;0180,0055,0365,0055,0,3|}";
								cmd += "{LC;0180,0080,0365,0080,0,3|}";
								cmd += "{LC;0180,0110,0365,0110,0,3|}";
								cmd += "{LC;0275,0080,0275,0110,0,3|}";
							}
							else if (j == 1)
							{
								x = new string[] { "460", "430", "435" };
								cmd += "{LC;0400,0025,0585,0245,1,3|}";
								cmd += "{LC;0400,0055,0585,0055,0,3|}";
								cmd += "{LC;0400,0080,0585,0080,0,3|}";
								cmd += "{LC;0400,0110,0585,0110,0,3|}";
								cmd += "{LC;0495,0080,0495,0110,0,3|}";
							}
							else
							{
								x = new string[] { "700", "660", "665" };
								cmd += "{LC;0620,0025,0805,0245,1,3|}";
								cmd += "{LC;0620,0055,0805,0055,0,3|}";
								cmd += "{LC;0620,0080,0805,0080,0,3|}";
								cmd += "{LC;0620,0110,0805,0110,0,3|}";
								cmd += "{LC;0715,0080,0715,0110,0,3|}";
							}

							cmd += "{PV01;0" + x[0] + ",0050,0025,0025,01,0,00,B|}";
							cmd += "{RV01;CODE|}";
							cmd += "{PV01;0" + x[1] + ",0075,0025,0025,01,0,00,B|}";
							cmd += "{RV01;" + ps.data[i * 3 + j][0] + "|}";
							cmd += "{PV01;0" + x[1] + ",0105,0025,0025,01,0,00,B|}";
							cmd += "{RV01;REV   " + ps.data[i * 3 + j][1] + "|}";
							cmd += "{XB03;0" + x[2] + ",0115,T,H,04,A,0|}";
							cmd += "{RB03;" + ps.data[i * 3 + j][2] + "|}";
						}
					}
					else
					{

						//행
						cmd += "{LC;0180,0025,0365,0245,1,3|}";
						cmd += "{LC;0180,0055,0365,0055,0,3|}";
						cmd += "{LC;0180,0080,0365,0080,0,3|}";
						cmd += "{LC;0180,0110,0365,0110,0,3|}";
						cmd += "{LC;0275,0080,0275,0110,0,3|}";
						//값
						cmd += "{PV01;0230,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0200,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3][0] + "|}";
						cmd += "{PV01;0200,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3][1] + "|}";
						cmd += "{XB03;0205,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3][2] + "|}";

						//행
						cmd += "{LC;0400,0025,0585,0245,1,3|}";
						cmd += "{LC;0400,0055,0585,0055,0,3|}";
						cmd += "{LC;0400,0080,0585,0080,0,3|}";
						cmd += "{LC;0400,0110,0585,0110,0,3|}";
						cmd += "{LC;0495,0080,0495,0110,0,3|}";
						//값
						cmd += "{PV01;0460,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0430,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 1][0] + "|}";
						cmd += "{PV01;0430,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 1][1] + "|}";
						cmd += "{XB03;0435,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 1][2] + "|}";

						//행
						cmd += "{LC;0620,0025,0805,0245,1,3|}";
						cmd += "{LC;0620,0055,0805,0055,0,3|}";
						cmd += "{LC;0620,0080,0805,0080,0,3|}";
						cmd += "{LC;0620,0110,0805,0110,0,3|}";
						cmd += "{LC;0715,0080,0715,0110,0,3|}";
						//값
						cmd += "{PV01;0700,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0660,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 2][0] + "|}";
						cmd += "{PV01;0660,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 2][1] + "|}";
						cmd += "{XB03;0665,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 2][2] + "|}";
					}

					cmd += "{XS;I,0001,0002C5101|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "34#$";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0) { x = new string[6] { "152", "198", "165", "167", "225", "180" }; }
							else if (j == 1) { x = new string[6] { "335", "381", "348", "350", "408", "363" }; }
							else { x = new string[6] { "520", "566", "533", "535", "593", "548" }; }

							cmd += "^FO" + x[0] + ",12^GB153,192,2^FS";
							cmd += "^FO" + x[0] + ",12^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB70,25,2^FS";
							cmd += "^FO" + x[1] + ",16^A1N,20,20^FDCODE^FS";
							cmd += "^FO" + x[2] + ",38^A1N,20,20^FD" + ps.data[i * 3 + j][0] + "^FS";
							cmd += "^FO" + x[3] + ",60^A1N,20,20^FDREV^FS";
							cmd += "^FO" + x[4] + ",60^A1N,20,20^FD" + ps.data[i * 3 + j][1] + "^FS";
							cmd += "^FO" + x[5] + ",85^BQN,2,4^FD123" + ps.data[i * 3 + j][2] + "^FS";
						}
					}
					else
					{
						cmd += "^FO152,12^GB153,192,2^FS";
						cmd += "^FO152,12^GB153,25,2^FS";
						cmd += "^FO152,57^GB153,25,2^FS";
						cmd += "^FO152,57^GB70,25,2^FS";
						cmd += "^FO198,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO165,38^A1N,20,20^FD" + ps.data[i * 3][0] + "^FS";
						cmd += "^FO167,60^A1N,20,20^FDREV^FS";
						cmd += "^FO225,60^A1N,20,20^FD" + ps.data[i * 3][1] + "^FS";
						cmd += "^FO180,85^BQN,2,4^FD123" + ps.data[i * 3][2] + "^FS";

						cmd += "^FO335,12^GB153,192,2^FS";
						cmd += "^FO335,12^GB153,25,2^FS";
						cmd += "^FO335,57^GB153,25,2^FS";
						cmd += "^FO335,57^GB70,25,2^FS";
						cmd += "^FO381,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO348,38^A1N,20,20^FD" + ps.data[i * 3 + 1][0] + "^FS";
						cmd += "^FO350,60^A1N,20,20^FDREV^FS";
						cmd += "^FO408,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO363,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";

						cmd += "^FO520,12^GB153,192,2^FS";
						cmd += "^FO520,12^GB153,25,2^FS";
						cmd += "^FO520,57^GB153,25,2^FS";
						cmd += "^FO520,57^GB70,25,2^FS";
						cmd += "^FO566,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO533,38^A1N,20,20^FD" + ps.data[i * 3 + 2][0] + "^FS";
						cmd += "^FO535,60^A1N,20,20^FDREV^FS";
						cmd += "^FO593,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO548,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";
					}
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//개별입고등록_기본
		private int IndividualLarge_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{D0900,1000,0900|}";
					cmd += "{C|}";
					cmd += "{LC;0060,0035,0930,0440,1,5|}";
					cmd += "{LC;0060,0105,0930,0105,0,5|}";
					cmd += "{LC;0060,0175,0930,0175,0,5|}";
					cmd += "{LC;0060,0245,0930,0245,0,5|}";
					cmd += "{LC;0060,0315,0930,0315,0,5|}";
					cmd += "{LC;0320,0035,0320,0315,0,5|}";

					cmd += "{PV01;0065,0080,0030,0030,01,0,00,B|}";
					cmd += "{RV01;CODE NO|}";
					cmd += "{PV01;0115,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;I T E M|}";
					cmd += "{PV01;0110,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;S P E C|}";
					cmd += "{PV01;0075,0290,0035,0035,01,0,00,B|}";
					cmd += "{RV01;입고일자/수량|}";

					cmd += "{PV01;0340,0080,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][0] + "|}";
					cmd += "{PV01;0340,0150,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][2] + "|}";
					cmd += "{PV01;0340,0225,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][3] + "|}";
					cmd += "{PV01;0340,0300,0040,0040,01,0,00,B|}";
					cmd += "{RV01;" + ps.data[i][4] + "    /    " + ps.data[i][5] + "|}";
					cmd += "{XB02;0230,0350,9,2,02,0,0050,+0000000000,000,1,00|}";
					cmd += "{RB02;" + ps.data[i][6] + "|}";

					cmd += "{XS;I,0001,0002C5101|}";
					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;
					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO70,10^GB200,73,3^FS";
					cmd += "^FO075,35^A1N,20,20^FDCODE NO/부품위치^FS";
					cmd += "^FO70,80^GB200,73,3^FS";
					cmd += "^FO110,105^A1N,30,30^FDI T E M^FS";
					cmd += "^FO70,150^GB200,73,3^FS";
					cmd += "^FO110,175^A1N,30,30^FDS P E C^FS";
					cmd += "^FO70,220^GB200,73,3^FS";
					cmd += "^FO85,245^A1N,25,25^FD입고일자/수량^FS";
					cmd += "^FO70,290^GB700,73,3^FS";
					if (ps.data[i][6].Length > 13)
					{
						cmd += "^FO150,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					else
					{
						cmd += "^FO250,297^BY2,3^BCN,40,Y,N,Y^FD" + ps.data[i][6] + "^FS";
					}
					cmd += "^FO267,10^GB503,73,3^FS";
					cmd += "^FO282,35^A1N,30,30^FD" + ps.data[i][0] + "    /    " + ps.data[i][1] + "^FS";
					cmd += "^FO267,80^GB503,73,3^FS";
					cmd += "^FO282,105^A1N,30,30^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO267,150^GB503,73,3^FS";
					cmd += "^FO282,175^A1N,30,30^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO267,220^GB503,73,3^FS";
					cmd += "^FO282,245^A1N,30,30^FD" + ps.data[i][4] + "    /    " + ps.data[i][5] + "^FS";
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");

					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//개별입고등록_개별
		private int IndividualSmall_Code(PrintString ps)
		{
			CreateExcel();
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "{D0780,1000,0750|}";
					cmd += "{C|}";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0)
							{
								x = new string[] { "230", "200", "205" };
								cmd += "{LC;0180,0025,0365,0245,1,3|}";
								cmd += "{LC;0180,0055,0365,0055,0,3|}";
								cmd += "{LC;0180,0080,0365,0080,0,3|}";
								cmd += "{LC;0180,0110,0365,0110,0,3|}";
								cmd += "{LC;0275,0080,0275,0110,0,3|}";
							}
							else if (j == 1)
							{
								x = new string[] { "460", "430", "435" };
								cmd += "{LC;0400,0025,0585,0245,1,3|}";
								cmd += "{LC;0400,0055,0585,0055,0,3|}";
								cmd += "{LC;0400,0080,0585,0080,0,3|}";
								cmd += "{LC;0400,0110,0585,0110,0,3|}";
								cmd += "{LC;0495,0080,0495,0110,0,3|}";
							}
							else
							{
								x = new string[] { "700", "660", "665" };
								cmd += "{LC;0620,0025,0805,0245,1,3|}";
								cmd += "{LC;0620,0055,0805,0055,0,3|}";
								cmd += "{LC;0620,0080,0805,0080,0,3|}";
								cmd += "{LC;0620,0110,0805,0110,0,3|}";
								cmd += "{LC;0715,0080,0715,0110,0,3|}";
							}

							cmd += "{PV01;0" + x[0] + ",0050,0025,0025,01,0,00,B|}";
							cmd += "{RV01;CODE|}";
							cmd += "{PV01;0" + x[1] + ",0075,0025,0025,01,0,00,B|}";
							cmd += "{RV01;" + ps.data[i * 3 + j][0] + "|}";
							cmd += "{PV01;0" + x[1] + ",0105,0025,0025,01,0,00,B|}";
							cmd += "{RV01;REV   " + ps.data[i * 3 + j][1] + "|}";
							cmd += "{XB03;0" + x[2] + ",0115,T,H,04,A,0|}";
							cmd += "{RB03;" + ps.data[i * 3 + j][2] + "|}";
						}
					}
					else
					{

						//행
						cmd += "{LC;0180,0025,0365,0245,1,3|}";
						cmd += "{LC;0180,0055,0365,0055,0,3|}";
						cmd += "{LC;0180,0080,0365,0080,0,3|}";
						cmd += "{LC;0180,0110,0365,0110,0,3|}";
						cmd += "{LC;0275,0080,0275,0110,0,3|}";
						//값
						cmd += "{PV01;0230,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0200,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3][0] + "|}";
						cmd += "{PV01;0200,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3][1] + "|}";
						cmd += "{XB03;0205,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3][2] + "|}";

						//행
						cmd += "{LC;0400,0025,0585,0245,1,3|}";
						cmd += "{LC;0400,0055,0585,0055,0,3|}";
						cmd += "{LC;0400,0080,0585,0080,0,3|}";
						cmd += "{LC;0400,0110,0585,0110,0,3|}";
						cmd += "{LC;0495,0080,0495,0110,0,3|}";
						//값
						cmd += "{PV01;0460,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0430,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 1][0] + "|}";
						cmd += "{PV01;0430,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 1][1] + "|}";
						cmd += "{XB03;0435,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 1][2] + "|}";

						//행
						cmd += "{LC;0620,0025,0805,0245,1,3|}";
						cmd += "{LC;0620,0055,0805,0055,0,3|}";
						cmd += "{LC;0620,0080,0805,0080,0,3|}";
						cmd += "{LC;0620,0110,0805,0110,0,3|}";
						cmd += "{LC;0715,0080,0715,0110,0,3|}";
						//값
						cmd += "{PV01;0700,0050,0025,0025,01,0,00,B|}";
						cmd += "{RV01;CODE|}";
						cmd += "{PV01;0660,0075,0025,0025,01,0,00,B|}";
						cmd += "{RV01;" + ps.data[i * 3 + 2][0] + "|}";
						cmd += "{PV01;0660,0105,0025,0025,01,0,00,B|}";
						cmd += "{RV01;REV   " + ps.data[i * 3 + 2][1] + "|}";
						cmd += "{XB03;0665,0115,T,H,04,A,0|}";
						cmd += "{RB03;" + ps.data[i * 3 + 2][2] + "|}";
					}

					cmd += "{XS;I,0001,0002C5101|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "34#$";
					cmd += "^XA";
					cmd += "^PRD";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					if (i + 1 == ps.printCnt)
					{
						for (int j = 0; j < ps.printOrder; j++)
						{
							string[] x;

							if (j == 0) { x = new string[6] { "152", "198", "165", "167", "225", "180" }; }
							else if (j == 1) { x = new string[6] { "335", "381", "348", "350", "408", "363" }; }
							else { x = new string[6] { "520", "566", "533", "535", "593", "548" }; }

							cmd += "^FO" + x[0] + ",12^GB153,192,2^FS";
							cmd += "^FO" + x[0] + ",12^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB153,25,2^FS";
							cmd += "^FO" + x[0] + ",57^GB70,25,2^FS";
							cmd += "^FO" + x[1] + ",16^A1N,20,20^FDCODE^FS";
							cmd += "^FO" + x[2] + ",38^A1N,20,20^FD" + ps.data[i * 3 + j][0] + "^FS";
							cmd += "^FO" + x[3] + ",60^A1N,20,20^FDREV^FS";
							cmd += "^FO" + x[4] + ",60^A1N,20,20^FD" + ps.data[i * 3 + j][1] + "^FS";
							cmd += "^FO" + x[5] + ",85^BQN,2,4^FD123" + ps.data[i * 3 + j][2] + "^FS";
						}
					}
					else
					{
						cmd += "^FO152,12^GB153,192,2^FS";
						cmd += "^FO152,12^GB153,25,2^FS";
						cmd += "^FO152,57^GB153,25,2^FS";
						cmd += "^FO152,57^GB70,25,2^FS";
						cmd += "^FO198,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO165,38^A1N,20,20^FD" + ps.data[i * 3][0] + "^FS";
						cmd += "^FO167,60^A1N,20,20^FDREV^FS";
						cmd += "^FO225,60^A1N,20,20^FD" + ps.data[i * 3][1] + "^FS";
						cmd += "^FO180,85^BQN,2,4^FD123" + ps.data[i * 3][2] + "^FS";

						cmd += "^FO335,12^GB153,192,2^FS";
						cmd += "^FO335,12^GB153,25,2^FS";
						cmd += "^FO335,57^GB153,25,2^FS";
						cmd += "^FO335,57^GB70,25,2^FS";
						cmd += "^FO381,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO348,38^A1N,20,20^FD" + ps.data[i * 3 + 1][0] + "^FS";
						cmd += "^FO350,60^A1N,20,20^FDREV^FS";
						cmd += "^FO408,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO363,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";

						cmd += "^FO520,12^GB153,192,2^FS";
						cmd += "^FO520,12^GB153,25,2^FS";
						cmd += "^FO520,57^GB153,25,2^FS";
						cmd += "^FO520,57^GB70,25,2^FS";
						cmd += "^FO566,16^A1N,20,20^FDCODE^FS";
						cmd += "^FO533,38^A1N,20,20^FD" + ps.data[i * 3 + 2][0] + "^FS";
						cmd += "^FO535,60^A1N,20,20^FDREV^FS";
						cmd += "^FO593,60^A1N,20,20^FD" + ps.data[i * 3 + 1][1] + "^FS";
						cmd += "^FO548,85^BQN,2,4^FD123" + ps.data[i * 3 + 1][2] + "^FS";
					}
					cmd += "^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		//소형제품라벨
		private int SmallProduct_Excel(PrintString ps)
		{
			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				for (int j = 0; j < 4; j++)
				{
					if (i + 1 == ps.printCnt)
					{
						if (j >= ps.printOrder)
						{
							ps.data[i] = new string[10];
						}
					}

					serialNum++;
					oSheet.Cells[2, 1 + j * 4] = ps.data[i][0];
					oSheet.Cells[3, 1 + j * 4] = ps.data[i][1];
					oSheet.Cells[3, 2 + j * 4] = ps.data[i][3];
					oSheet.Cells[4, 1 + j * 4] = ps.data[i][2];
					oSheet.Cells[4, 2 + j * 4] = ps.data[i][4];
					oSheet.Cells[5, 1 + j * 4] = ps.data[i][6] + ChangeSerialNum(serialNum);
					oSheet.Cells[7, 1 + j * 4] = ps.data[i][9];
					oSheet.Cells[8, 1 + j * 4] = ps.data[i][7];
				}

				oSheet.Application.Run("PRINT_LABEL");

				DeleteExcel(oXL);
			}

			return 0;
		}

		//중형제품라벨(1)
		private int mediumProduct_1_Excel(PrintString ps)
		{

			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				oSheet.Cells[3, 1] = ps.data[i][0];
				oSheet.Cells[3, 2] = ps.data[i][1] + "kW";
				oSheet.Cells[5, 1] = ps.data[i][2];
				oSheet.Cells[6, 1] = ps.data[i][3];
				oSheet.Cells[7, 1] = ps.data[i][8];
				oSheet.Cells[8, 1] = ps.data[i][6] + ChangeSerialNum(serialNum);

				oSheet.Application.Run("PRINT_LABEL");

				DeleteExcel(oXL);
			}

			return 0;
		}

		//중형제품라벨(2)
		private int mediumProduct_2_Excel(PrintString ps)
		{
			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				for (int j = 0; j < 2; j++)
				{
					if (i + 1 == ps.printCnt)
					{
						if (j >= ps.printOrder)
						{
							ps.data[i] = new string[10];
						}
					}

					serialNum++;
					oSheet.Cells[2, 1 + j * 5] = ps.data[i][0];
					oSheet.Cells[3, 1 + j * 5] = ps.data[i][1];
					oSheet.Cells[3, 2 + j * 5] = ps.data[i][3];
					oSheet.Cells[2, 4 + j * 5] = ps.data[i][11];
					oSheet.Cells[3, 4 + j * 5] = ps.data[i][12];
					oSheet.Cells[4, 1 + j * 5] = ps.data[i][2];
					oSheet.Cells[4, 2 + j * 5] = ps.data[i][4];
					oSheet.Cells[4, 4 + j * 5] = ps.data[i][5] + " PPR";
					oSheet.Cells[5, 1 + j * 5] = ps.data[i][6] + ChangeSerialNum(serialNum);
					oSheet.Cells[6, 1 + j * 5] = ps.data[i][9];
					oSheet.Cells[7, 1 + j * 5] = ps.data[i][7];

					oSheet.Application.Run("PRINT_LABEL");

					DeleteExcel(oXL);
				}
			}

			return 0;
		}

		//소형BOX라벨
		private int smallBox_Excel(PrintString ps)
		{

			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				oSheet.Cells[3, 4] = ps.data[i][1] + " kW";
				oSheet.Cells[4, 4] = ps.data[i][2] + " RPM";
				oSheet.Cells[5, 4] = ps.data[i][3] + " Nm";
				oSheet.Cells[6, 4] = ps.data[i][4] + " Arms";
				oSheet.Cells[7, 4] = ps.data[i][5] + " PPR";
				oSheet.Cells[10, 2] = ps.data[i][0];
				oSheet.Cells[11, 1] = "*" + ps.data[i][10] + "*";
				oSheet.Cells[14, 2] = ps.data[i][6] + ChangeSerialNum(serialNum);

				oSheet.Application.Run("PRINT_LABEL");

				DeleteExcel(oXL);
			}

			return 0;
		}

		//중형BOX라벨
		private int mediumBox_Excel(PrintString ps)
		{

			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				oSheet.Cells[1, 2] = ps.data[i][1] + " kW";
				oSheet.Cells[1, 3] = ps.data[i][2] + " RPM";
				oSheet.Cells[1, 4] = ps.data[i][3] + " Nm";
				oSheet.Cells[1, 5] = ps.data[i][4] + " Arms";
				oSheet.Cells[1, 6] = ps.data[i][5] + " PPR INC";
				oSheet.Cells[1, 8] = ps.data[i][0];
				oSheet.Cells[1, 9] = "*" + ps.data[i][10] + "*";
				oSheet.Cells[1, 10] = ps.data[i][6] + ChangeSerialNum(serialNum);

				oSheet.Application.Run("PRINT_LABEL");

				DeleteExcel(oXL);
			}

			return 0;
		}

		//반제품라벨
		private int halfProduct_Excel(PrintString ps)
		{

			//Excel Setting
			Excel.Workbook oWB = null;
			Excel.Worksheet oSheet = null;

			int serialNum = 0;

			for (int i = 0; i < ps.printCnt; i++)
			{
				Excel.Application oXL = CreateExcel();
				oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\Komotek\Paper\" + ps.paperSize + ".xlsm"));
				oSheet = (Excel.Worksheet)oWB.ActiveSheet;

				//Add table headers going cell by cell.
				oSheet.Cells[1, 2] = ps.data[i][0];
				oSheet.Cells[2, 2] = ps.data[i][1];
				oSheet.Cells[3, 2] = ps.data[i][2];
				oSheet.Cells[4, 2] = ps.data[i][4] + "/" + ps.data[i][5];
				oSheet.Cells[5, 1] = "*" + ps.data[i][3] + "*";
				oSheet.Cells[6, 1] = ps.data[i][3];

				oSheet.Application.Run("PRINT_LABEL");

				DeleteExcel(oXL);
			}

			return 0;
		}
	}
}
