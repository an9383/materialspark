﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HyginoEdgeGW.PRN;
using Excel = Microsoft.Office.Interop.Excel;

namespace HyginoEdgeGW.PRN.IfPrinter
{
    class Soulbrain : Printer
    {
        Printer printer = new Printer();

        //생성자
        public int PrintSLD(PrintString ps)
        {
            int result = 0;

            if (ps.printType == "코드")
            {
                switch (ps.paperSize)
                {
                    case "productionTray":
                        result = ProductionTray_Code(ps); break;
                    case "pallet":
                        result = Pallet_Code(ps); break;
                    case "lgesTray":
                        result = LgesTray_Code(ps); break;
                    default:
                        result = 0; break;
                }
            }
            else if (ps.printType == "엑셀")
            {
                switch (ps.paperSize)
                {
                    case "productionTray":
                        result = ProductionTray_Excel(ps); break;
                    case "pallet":
                        result = Pallet_Excel(ps); break;
                    default:
                        result = 0; break;
                }
            }

            return result;
        }

        //생산실적(Tray)_코드
        private int ProductionTray_Code(PrintString ps)
        {
            bool result = true;
            int failCount = 0;

            for (int i = 0; i < ps.printCnt; i++) {
                string imgCommand = bmpToCommand(Directory.GetCurrentDirectory() + @"\SLD\Image\" + ps.data[i][4] + ".bmp");
                string cmd = "{AX;+000,+000,+00|}";
                cmd += "{AY;+10,0|}";
                cmd += "{D0280,1000,0250|}"; 
                cmd += "{C|}";

                cmd += "{SG;0010,0050,0080,0080,0,"+imgCommand+"|}";
                cmd += "{XB01;0150,0050,9,2,01,0,0080,+0000000001,000,0,00|}";
                cmd += "{RB01;" + ps.data[i][0] + "|}";
                cmd += "{PV23;0150,0155,0030,0030,01,0,00,B=" + ps.data[i][0] + "|}";
                cmd += "{PV23;0070,0200,0032,0032,01,0,00,B=" + ps.data[i][1] + "|}";
                cmd += "{PV23;0220,0200,0032,0032,01,0,00,B=" + ps.data[i][2] + "|}";
                cmd += "{PV23;0320,0200,0032,0032,01,0,00,B=" + ps.data[i][3] + "EA|}";

                cmd += "{SG;0545,0050,0080,0080,0," + imgCommand + "|}";
                cmd += "{XB02;0685,0050,9,2,01,0,0080,+0000000001,000,0,00|}";
                cmd += "{RB02;" + ps.data[i][0] + "|}";
                cmd += "{PV23;0685,0155,0030,0030,01,0,00,B=" + ps.data[i][0] + "|}";
                cmd += "{PV23;0600,0200,0032,0032,01,0,00,B=" + ps.data[i][1] + "|}";
                cmd += "{PV23;0750,0200,0032,0032,01,0,00,B=" + ps.data[i][2] + "|}";
                cmd += "{PV23;0850,0200,0032,0032,01,0,00,B=" + ps.data[i][3] + "EA|}";

                cmd += "{XS;I,0001,0002C5101|}";

                result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
                if (result == false)
                {
                    failCount++;
                }
            }

            return failCount;
        }



        //생산실적(Tray)_엑셀
        private int ProductionTray_Excel(PrintString ps)
        {
            //Excel Setting
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;

            int failCount = 0;
            bool result = true;

            for (int i = 0; i < ps.printCnt; i++)
            {
                try
                {
                    Excel.Application oXL = printer.CreateExcel();
                    oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\SLD\Paper\" + ps.paperSize + ".xlsm"));
                    oSheet = (Excel.Worksheet)oWB.ActiveSheet;

                    //사진 읽기
                    Excel.Pictures p = oSheet.Pictures(Type.Missing) as Excel.Pictures;
                    Excel.Picture pic = null;
                    Excel.Picture pic2 = null;

                    //사진 위치설정
                    pic = p.Insert(Filename: Directory.GetCurrentDirectory() + @"\SLD\Image\" + ps.data[i][4] + ".bmp", Type.Missing);
                    pic.ShapeRange.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoCTrue;
                    pic.ShapeRange.Width = 28;
                    pic.ShapeRange.Height = 28;
                    pic.Left = 5;
                    pic.Top = 45;

                    // 3장일때
                    /*
                    if (i + 1 == ps.printCnt)
                    {
                        if (ps.data[i * 2][1] == null || ps.data[i * 2][1].Equals("null"))
                        {
                            ps.data[i * 2][1] = "DE/SK";
                        }
                        oSheet.Cells[1, 2] = "*" + ps.data[i * 2][0] + "*";
                        oSheet.Cells[2, 2] = ps.data[i * 2][0];
                        oSheet.Cells[3, 2] = ps.data[i * 2][1];
                        oSheet.Cells[3, 3] = ps.data[i * 2][2];
                        oSheet.Cells[3, 4] = ps.data[i * 2][3] + "EA";

                        if (ps.printOrder == 2)
                        {
                            //사진 위치설정
                            pic2 = p.Insert(Filename: Directory.GetCurrentDirectory() + @"\SLD\Image\" + ps.data[i][4] + ".bmp", Type.Missing);
                            pic2.ShapeRange.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoCTrue;
                            pic2.ShapeRange.Width = 27;
                            pic2.ShapeRange.Height = 27;
                            pic2.Left = 180;
                            pic2.Top = 40;

                            if (ps.data[i * 2 + 1][1] == null || ps.data[i * 2 + 1][1].Equals("null"))
                            {
                                ps.data[i * 2 + 1][1] = "DE/SK";
                            }
                            oSheet.Cells[1, 7] = "*" + ps.data[i][0] + "*";
                            oSheet.Cells[2, 7] = ps.data[i * 2 + 1][0];
                            oSheet.Cells[3, 7] = ps.data[i * 2 + 1][1];
                            oSheet.Cells[3, 8] = ps.data[i * 2 + 1][2];
                            oSheet.Cells[3, 9] = ps.data[i * 2 + 1][3] + "EA";
                        }
                    }
                    else
                    {
                    */
                        //사진 위치설정
                        pic2 = p.Insert(Filename: Directory.GetCurrentDirectory() + @"\SLD\Image\" + ps.data[i][4] + ".bmp", Type.Missing);
                        pic2.ShapeRange.LockAspectRatio = Microsoft.Office.Core.MsoTriState.msoCTrue;
                        pic2.ShapeRange.Width = 28;
                        pic2.ShapeRange.Height = 28;
                        pic2.Left = 178;
                        pic2.Top = 45;

                        if (ps.data[i * 2][1] == null || ps.data[i * 2][1].Equals("null"))
                        {
                            ps.data[i * 2][1] = "DE/SK";
                        }
                        oSheet.Cells[1, 1] = "*" + ps.data[i * 2][0] + "*";
                        oSheet.Cells[2, 1] = ps.data[i * 2][0];
                        oSheet.Cells[3, 2] = ps.data[i * 2][1];
                        oSheet.Cells[3, 3] = ps.data[i * 2][2];
                        oSheet.Cells[3, 4] = ps.data[i * 2][3] + "EA";


                        if (ps.data[i * 2 + 1][1] == null || ps.data[i * 2 + 1][1].Equals("null"))
                        {
                            ps.data[i * 2 + 1][1] = "DE/SK";
                        }
                        oSheet.Cells[1, 6] = "*" + ps.data[i][0] + "*";
                        oSheet.Cells[2, 6] = ps.data[i * 2 + 1][0];
                        oSheet.Cells[3, 7] = ps.data[i * 2 + 1][1];
                        oSheet.Cells[3, 8] = ps.data[i * 2 + 1][2];
                        oSheet.Cells[3, 9] = ps.data[i * 2 + 1][3] + "EA";
                    //}

                    oSheet.Application.Run("PRINT_LABEL");

                    printer.DeleteExcel(oXL);
                }
                catch (Exception theException)
                {
                    String errorMessage;
                    errorMessage = "Error: ";
                    errorMessage = String.Concat(errorMessage, theException.Message);
                    errorMessage = String.Concat(errorMessage, " Line: ");
                    errorMessage = String.Concat(errorMessage, theException.Source);
                    failCount++;
                }
            }

            return failCount;
        }

        //파레트포장_엑셀
        private int Pallet_Excel(PrintString ps)

        {
            //Excel Setting
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;

            int failCount = 0;
            bool result = true;

            for (int i = 0; i < ps.printCnt; i++)
            {
                try
                {
                    Excel.Application oXL = printer.CreateExcel();
                    oWB = (Excel.Workbook)(oXL.Workbooks.Open(Filename: Directory.GetCurrentDirectory() + @"\SLD\Paper\" + ps.paperSize + ".xlsm"));
                    oSheet = (Excel.Worksheet)oWB.ActiveSheet;

                    oSheet.Cells[1, 2] = ps.data[i][0];//고객사
                    oSheet.Cells[2, 2] = ps.data[i][1];//출하일
                    oSheet.Cells[3, 2] = ps.data[i][2];//모델명
                    oSheet.Cells[4, 2] = ps.data[i][3];//파레트 no
                    oSheet.Cells[5, 2] = ps.data[i][4] + "/" + ps.data[i][5];//박스 카운트
                    oSheet.Cells[6, 1] = "*" + ps.data[i][3] + "*";//바코드

                    oSheet.Application.Run("PRINT_LABEL");

                    printer.DeleteExcel(oXL);
                }
                catch (Exception theException)
                {
                    String errorMessage;
                    errorMessage = "Error: ";
                    errorMessage = String.Concat(errorMessage, theException.Message);
                    errorMessage = String.Concat(errorMessage, " Line: ");
                    errorMessage = String.Concat(errorMessage, theException.Source);
                    failCount++;
                }
            }

            return failCount;
        }

        //파레트포장_코드
        private int Pallet_Code(PrintString ps)
        {
            bool result = true;
            int failCount = 0;

            for (int i = 0; i < ps.printCnt; i++)
            {
                string cmd = "{AX;+000,+000,+00|}";
                cmd += "{AY;+10,0|}";
                cmd += "{D0580,0900,0550|}";
                cmd += "{C|}";

                cmd += "{LC;0030,0050,0900,0530,1,5|}";

                cmd += "{PV23;0218,0130,0045,0045,01,0,00,B=고객사 : " + ps.data[i][0] + "|}";//고객사
                cmd += "{PV23;0218,0200,0045,0045,01,0,00,B=납기일 : " + ps.data[i][1] + "|}";//출하일
                cmd += "{PV23;0218,0270,0045,0045,01,0,00,B=모델명 : " + ps.data[i][2] + "|}";//모델명
                cmd += "{PV23;0150,0340,0045,0045,01,0,00,B=Pallet NO : " + ps.data[i][3] + "|}";//파레트no
                cmd += "{PV23;0093,0400,0045,0045,01,0,00,B=BOX COUNT : " + ps.data[i][4] + "/" + ps.data[i][5] + " (" + ps.data[i][6] + "EA) " + ps.data[i][8] + "|}";//박스카운트

                cmd += "{XB02;0350,0430,9,3,01,0,0065,+0000000001,000,0,00|}";
                cmd += "{RB02;" + ps.data[i][7] + "|}"; //바코드
                cmd += "{PV23;0330,0520,0025,0025,01,0,00,B=" + ps.data[i][7] + "|}";//바코드번호

                cmd += "{XS;I,0001,0002C5101|}";

                result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
                if (result == false)
                {
                    failCount++;
                }
            }
            return failCount;
        }

        //공정실적관리(POP)/작업지시선택_코드
        private int LgesTray_Code(PrintString ps)
        {
            bool result = true;
            int failCount = 0;
            int labelCount = 0;

            for (int i = 0; i < ps.printCnt; i++)
            {
                string cmd = "{D0170,1030,0140|}";
                cmd += "{AX;+000,+000,+00|}";
                cmd += "{AY;+10,0|}";
                cmd += "{C|}";

                // 트레이 라벨
                if (ps.printOrder == 0)
                {
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(40, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2][0] + "|}";
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(80, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2][1] + "|}";
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(120, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2][2] + "|}";
                    cmd += "{XB03;" + AutoCal(381, ps.moveX) + "," + AutoCal(16, ps.moveY) + ",T,L,03,A,0|}";
                    cmd += "{RB03;" + ps.data[i * 2][3] + "|}";
                    cmd += "{PV23;" + AutoCal(550, ps.moveX) + "," + AutoCal(40, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2 + 1][0] + "|}";
                    cmd += "{PV23;" + AutoCal(550, ps.moveX) + "," + AutoCal(80, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2 + 1][1] + "|}";
                    cmd += "{PV23;" + AutoCal(550, ps.moveX) + "," + AutoCal(120, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2 + 1][2] + "|}";
                    cmd += "{XB03;" + AutoCal(911, ps.moveX) + "," + AutoCal(16, ps.moveY) + ",T,L,03,A,0|}";
                    cmd += "{RB03;" + ps.data[i * 2 + 1][3] + "|}";
                }

                // 내부 라벨
                if (ps.printOrder == 1)
                {
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(40, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2][0] + "|}";
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(80, ps.moveY) + ",0030,0037,01,0,00,B=" + ps.data[i * 2][1] + "|}";
                    cmd += "{PV23;" + AutoCal(20, ps.moveX) + "," + AutoCal(120, ps.moveY) + ",0030,0035,01,0,00,B=" + ps.data[i * 2][2] + "|}";
                    cmd += "{XB03;" + AutoCal(381, ps.moveX) + "," + AutoCal(16, ps.moveY) + ",T,L,04,A,0|}";
                    cmd += "{RB03;" + ps.data[i * 2][3] + "|}";
                }

                cmd += "{XS;I,0001,0002C5101|}";

                result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");
                if (result == false)
                {
                    failCount++;
                }
            }

            return failCount;
        }

        private String AutoCal(int op, int mp)
        {
            String resultPos = "";
            resultPos = "000" + (op + mp);
            return resultPos.Substring(resultPos.Length - 4);
        }

    }
}