﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HyginoEdgeGW.PRN.IfPrinter
{
    class DaerimAuto : Printer
    {
        PrintString pS = new PrintString();

        public int PrintDaerim(PrintString ps)
        {
            int result = 0;

            if (ps.printType == "코드")
            {
				switch (ps.paperSize)
				{
					case "prodPerformance":
						result = ProdPerformance_Code(ps); break;
					case "currentStock":
						result = CurrentStock_Code(ps); break;
					case "commonLabel":
						result = CommonLabel_Code(ps); break;
					case "materialLabel":
						result = MaterialLabel_Code(ps); break;
					case "productLabel":
						result = ProductLabel_Code(ps); break;
					default:
						result = 0; break;
				}
			}
            return result;
        }

		// 생산실적
		private int ProdPerformance_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;
			string cmd = "";

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "{D0520,0980,0500|}";
					cmd += "{AY;+04,0|}";
					cmd += "{AX;-020,+000,+00|}";
					cmd += "{C|}";

					//행
					cmd += "{LC;0010,0035,0980,0110,1,5|}";
					cmd += "{LC;0010,0035,0980,0180,1,5|}";
					cmd += "{LC;0010,0035,0980,0250,1,5|}";
					cmd += "{LC;0010,0035,0980,0320,1,5|}";
					cmd += "{LC;0010,0035,0980,0485,1,5|}";
					cmd += "{LC;0659,0184,0980,0380,1,5|}";

					//열
					cmd += "{LC;0155,0035,0155,0320,0,5|}";

					cmd += "{LC;0655,0035,0655,0110,0,5|}";
					cmd += "{LC;0800,0035,0800,0110,0,5|}";

					cmd += "{LC;0350,0180,0350,0320,0,5|}";
					cmd += "{LC;0505,0180,0505,0320,0,5|}";
					cmd += "{LC;0655,0180,0655,0485,0,5|}";
					cmd += "{LC;0800,0180,0800,0320,0,5|}";

					//데이터
					cmd += "{PV23;0015,0090,0040,0040,01,0,00,B=품목번호|}";
					cmd += "{PV23;0165,0090,0040,0040,01,0,00,B=" + ps.data[i][0] + "|}";
					cmd += "{PV23;0015,0160,0040,0040,01,0,00,B=품명|}";
					cmd += "{PV23;0165,0160,0040,0040,01,0,00,B=" + ps.data[i][1] + "|}";
					cmd += "{PV23;0015,0230,0040,0040,01,0,00,B=생산일|}";
					cmd += "{PV23;0165,0230,0040,0040,01,0,00,B=" + ps.data[i][5] + "|}";
					cmd += "{PV23;0015,0300,0040,0040,01,0,00,B=생산수량|}";
					cmd += "{PV23;0165,0300,0040,0040,01,0,00,B=" + ps.data[i][11] + "|}";
					cmd += "{PV23;0360,0230,0040,0040,01,0,00,B=자주검사|}";
					cmd += "{PV23;0520,0230,0040,0040,01,0,00,B=" + ps.data[i][9] + "|}";
					cmd += "{PV23;0360,0300,0040,0040,01,0,00,B=작업자|}";
					cmd += "{PV23;0520,0300,0040,0040,01,0,00,B=" + ps.data[i][4] + "|}";
					cmd += "{PV23;0670,0090,0040,0040,01,0,00,B=차종|}";
					cmd += "{PV23;0820,0090,0040,0040,01,0,00,B=" + ps.data[i][2] + "|}";
					cmd += "{PV23;0670,0230,0040,0040,01,0,00,B=창고|}";
					cmd += "{PV23;0820,0230,0040,0040,01,0,00,B=" + ps.data[i][8] + "|}";
					cmd += "{PV23;0670,0300,0040,0040,01,0,00,B=고객사|}";
					cmd += "{PV23;0820,0300,0040,0040,01,0,00,B=" + ps.data[i][6] + "|}";
					cmd += "{PV23;0710,0365,0040,0040,01,0,00,B=" + "공정검사확인" + "|}";
					cmd += "{PV23;0770,0450,0040,0040,01,0,00,B=" + ps.data[i][14] + "|}";
					if (ps.data[i][13].Length < 12)
						cmd += "{XB03;0120,0350,9,3,02,0,0100,+0000000001,000,1,00|}";
					else
						cmd += "{XB03;0080,0350,9,3,02,0,0100,+0000000001,000,1,00|}";
					cmd += "{RB03;" + ps.data[i][13] + "|}";
					cmd += "{XS;I,0001,0002C4001|}";
					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "^XA";
					cmd += "^CI28";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO30,20^GB125,63,3^FS";
					cmd += "^FO35,35^A1N,28,28^FD품목번호^FS";
					cmd += "^FO152,20^GB388,63,3^FS";
					cmd += "^FO160,35^A1N,30,30^FD" + ps.data[i][0] + "^FS";
					cmd += "^FO539,20^GB105,63,3^FS";
					cmd += "^FO560,35^A1N,28,28^FD차종^FS";
					cmd += "^FO565,20^GB158,63,3^FS";
					cmd += "^FO660,35^A1N,28,28^FD" + ps.data[i][2] + "^FS";

					cmd += "^FO30,80^GB125,63,3^FS";
					cmd += "^FO60,100^A1N,30,30^FD품명^FS";
					cmd += "^FO152,80^GB648,63,3^FS";
					cmd += "^FO160,100^A1N,30,30^FD" + ps.data[i][1] + "^FS";

					cmd += "^FO30,140^GB125,63,3^FS";
					cmd += "^FO48,160^A1N,30,30^FD생산일^FS";
					cmd += "^FO152,140^GB155,63,3^FS";
					cmd += "^FO160,165^A1N,22,25^FD" + ps.data[i][5] + "^FS";
					cmd += "^FO304,140^GB135,63,3^FS";
					cmd += "^FO308,160^A1N,30,30^FD자주검사^FS";
					cmd += "^FO436,140^GB105,63,3^FS";
					cmd += "^FO445,160^A1N,28,28^FD" + ps.data[i][15] + "^FS";
					cmd += "^FO539,140^GB105,63,3^FS";
					cmd += "^FO560,160^A1N,28,28^FD창고^FS";
					cmd += "^FO642,140^GB158,63,3^FS";
					cmd += "^FO660,160^A1N,28,28^FD" + ps.data[i][8] + "^FS";
					cmd += "^FO30,200^GB125,63,3^FS";
					cmd += "^FO35,220^A1N,28,28^FD생산수량^FS";
					cmd += "^FO152,200^GB155,63,3^FS";
					cmd += "^FO160,220^A1N,25,25^FD" + ps.data[i][11] + "^FS";
					cmd += "^FO304,200^GB135,63,3^FS";
					cmd += "^FO308,220^A1N,30,30^FD작업자^FS";
					cmd += "^FO436,200^GB105,63,3^FS";
					cmd += "^FO445,222^A1N,21,19^FD" + ps.data[i][4] + "^FS";
					cmd += "^FO539,200^GB105,63,3^FS";
					cmd += "^FO550,220^A1N,28,28^FD고객사^FS";
					cmd += "^FO642,200^GB158,63,3^FS";
					cmd += "^FO650,220^A1N,23,22^FD" + ps.data[i][6] + "^FS";

					cmd += "^FO30,260^GB511,143,3^FS";
					cmd += "^FO50,280^BCN,80,Y,N,N^FD" + ps.data[i][13] + "^FS";
					cmd += "^FO539,260^GB261,53,3^FS";
					cmd += "^FO585,275^A1N,28,28^FD공정검사확인^FS";
					cmd += "^FO539,310^GB261,93,3^FS";
					cmd += "^FO610,340^A1N,28,28^FD" + ps.data[i][14] + "^FS";
					cmd += "^XZ";
					cmd += "^XA^JB^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
				}
				if (result == false)
				{
					failCount++;
				}
			}

			return failCount;
		}

		// 현재고현황
		private int CurrentStock_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;
			string cmd = "";

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "{AY;+04,0|}";
					cmd += "{AX;-020,+000,+00|}";
					cmd += "{C|}";

					//행
					cmd += "{LC;0010,0035,0980,0110,1,5|}";
					cmd += "{LC;0010,0035,0980,0180,1,5|}";
					cmd += "{LC;0010,0035,0980,0250,1,5|}";
					cmd += "{LC;0010,0035,0980,0320,1,5|}";
					cmd += "{LC;0010,0035,0980,0485,1,5|}";

					//열
					cmd += "{LC;0155,0035,0155,0320,0,5|}";
					cmd += "{LC;0335,0180,0335,0320,0,5|}";
					cmd += "{LC;0490,0180,0490,0320,0,5|}";
					cmd += "{LC;0640,0180,0640,0320,0,5|}";
					cmd += "{LC;0795,0180,0795,0320,0,5|}";

					//데이터
					cmd += "{PV23;0015,0090,0040,0040,01,0,00,B=품목번호|}";
					cmd += "{PV23;0170,0090,0040,0040,01,0,00,B=" + ps.data[i][0] + "|}";
					cmd += "{PV23;0045,0160,0040,0040,01,0,00,B=품명|}";
					cmd += "{PV23;0170,0160,0040,0040,01,0,00,B=" + ps.data[i][1] + "|}";
					cmd += "{PV23;0030,0230,0040,0040,01,0,00,B=입고일|}";
					cmd += "{PV23;0170,0230,0035,0035,01,0,00,B=" + ps.data[i][2] + "|}";
					cmd += "{PV23;0015,0300,0040,0040,01,0,00,B=" + ps.data[i][5] + "|}";
					cmd += "{PV23;0170,0300,0035,0035,01,0,00,B=" + ps.data[i][6] + "|}";
					cmd += "{PV23;0345,0230,0040,0040,01,0,00,B=합부판정|}";
					cmd += "{PV23;0517,0230,0040,0040,01,0,00,B=" + ps.data[i][3] + "|}";
					cmd += "{PV23;0345,0300,0040,0040,01,0,00,B=업체로트|}";
					cmd += "{PV23;0505,0300,0035,0035,01,0,00,B=" + ps.data[i][7] + "|}";
					cmd += "{PV23;0650,0230,0032,0032,01,0,00,B=재포장일자|}";
					cmd += "{PV23;0810,0230,0035,0035,01,0,00,B=" + ps.data[i][4] + "|}";
					cmd += "{PV23;0650,0300,0040,0040,01,0,00,B=유효기간|}";
					cmd += "{PV23;0810,0300,0035,0035,01,0,00,B=" + ps.data[i][8] + "|}";
					cmd += "{XB03;0160,0350,9,3,03,0,0100,+0000000001,000,1,00|}";
					cmd += "{RB03;" + ps.data[i][9] + "|}";
					cmd += "{XS;I,0001,0002C4001|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "^XA";
					cmd += "^CI28";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO30,20^GB125,63,3^FS";
					cmd += "^FO35,35^A1N,28,28^FD품목번호^FS";
					cmd += "^FO152,20^GB648,63,3^FS";
					cmd += "^FO160,35^A1N,30,30^FD" + ps.data[i][0] + "^FS";
					cmd += "^FO30,80^GB125,63,3^FS";
					cmd += "^FO60,100^A1N,30,30^FD품명^FS";
					cmd += "^FO152,80^GB648,63,3^FS";
					cmd += "^FO160,100^A1N,30,30^FD" + ps.data[i][1] + "^FS";

					cmd += "^FO30,140^GB125,63,3^FS";
					cmd += "^FO48,160^A1N,30,30^FD입고일^FS";
					cmd += "^FO152,140^GB155,63,3^FS";
					cmd += "^FO160,165^A1N,22,25^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO304,140^GB135,63,3^FS";
					cmd += "^FO308,160^A1N,30,30^FD합부판정^FS";
					cmd += "^FO436,140^GB105,63,3^FS";
					cmd += "^FO445,160^A1N,28,28^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO539,140^GB125,63,3^FS";
					cmd += "^FO545,160^A1N,23,23^FD재포장일자^FS";
					cmd += "^FO662,140^GB138,63,3^FS";
					cmd += "^FO665,160^A1N,23,23^FD" + ps.data[i][4] + "^FS";

					cmd += "^FO30,200^GB125,63,3^FS";
					cmd += "^FO35,220^A1N,28,28^FD" + ps.data[i][5] + "^FS";
					cmd += "^FO152,200^GB155,63,3^FS";
					cmd += "^FO160,220^A1N,25,25^FD" + ps.data[i][6] + "^FS";
					cmd += "^FO304,200^GB135,63,3^FS";
					cmd += "^FO308,220^A1N,30,30^FD업체로트^FS";
					cmd += "^FO436,200^GB105,63,3^FS";
					cmd += "^FO445,222^A1N,21,19^FD" + ps.data[i][7] + "^FS";
					cmd += "^FO539,200^GB125,63,3^FS";
					cmd += "^FO545,220^A1N,28,28^FD유효기간^FS";
					cmd += "^FO662,200^GB138,63,3^FS";
					cmd += "^FO665,220^A1N,23,23^FD" + ps.data[i][8] + "^FS";

					cmd += "^FO30,260^GB770,143,3^FS";
					cmd += "^FO170,280^BCN,80,Y,N,N^FD" + ps.data[i][9] + "^FS";
					cmd += "^XZ";
					cmd += "^XA^JB^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
				}
				if (result == false)
				{
					failCount++;

				}
			}

			return failCount;
		}

		// 입고등록, 외주입고, 입고라벨출력
		private int CommonLabel_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;
			string cmd = "";

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "{D0520,0980,0500|}";
					cmd += "{AY;+04,0|}";
					cmd += "{AX;-020,+000,+00|}";
					cmd += "{C|}";

					//행
					cmd += "{LC;0010,0035,0980,0110,1,5|}";
					cmd += "{LC;0010,0035,0980,0180,1,5|}";
					cmd += "{LC;0010,0035,0980,0250,1,5|}";
					cmd += "{LC;0010,0035,0980,0320,1,5|}";
					cmd += "{LC;0010,0035,0980,0485,1,5|}";

					//열
					cmd += "{LC;0155,0035,0155,0320,0,5|}";
					cmd += "{LC;0335,0180,0335,0320,0,5|}";
					cmd += "{LC;0490,0180,0490,0320,0,5|}";
					cmd += "{LC;0640,0180,0640,0320,0,5|}";
					cmd += "{LC;0795,0180,0795,0320,0,5|}";

					//데이터
					cmd += "{PV23;0015,0090,0040,0040,01,0,00,B=품목번호|}";
					cmd += "{PV23;0170,0090,0040,0040,01,0,00,B=" + ps.data[i][0] + "|}";
					cmd += "{PV23;0045,0160,0040,0040,01,0,00,B=품명|}";
					cmd += "{PV23;0170,0160,0040,0040,01,0,00,B=" + ps.data[i][1] + "|}";
					cmd += "{PV23;0030,0230,0040,0040,01,0,00,B=입고일|}";
					cmd += "{PV23;0170,0230,0035,0035,01,0,00,B=" + ps.data[i][2] + "|}";
					cmd += "{PV23;0015,0300,0040,0040,01,0,00,B=입고수량|}";
					cmd += "{PV23;0170,0300,0035,0035,01,0,00,B=" + ps.data[i][5] + "|}";
					cmd += "{PV23;0345,0230,0040,0040,01,0,00,B=합부판정|}";
					cmd += "{PV23;0517,0230,0040,0040,01,0,00,B=" + ps.data[i][3] + "|}";
					cmd += "{PV23;0345,0300,0040,0040,01,0,00,B=업체로트|}";
					cmd += "{PV23;0505,0300,0035,0035,01,0,00,B=" + ps.data[i][6] + "|}";
					cmd += "{PV23;0681,0230,0040,0040,01,0,00,B=창고|}";
					cmd += "{PV23;0810,0230,0035,0035,01,0,00,B=" + ps.data[i][4] + "|}";
					cmd += "{PV23;0670,0300,0040,0040,01,0,00,B=업체명|}";
					cmd += "{PV23;0810,0300,0035,0035,01,0,00,B=" + ps.data[i][7] + "|}";
					cmd += "{XB03;0160,0350,9,3,03,0,0100,+0000000001,000,1,00|}";
					cmd += "{RB03;" + ps.data[i][8] + "|}";
					cmd += "{XS;I,0001,0002C4001|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					cmd += "^XA";
					cmd += "^CI28";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";
					cmd += "^FO30,20^GB125,63,3^FS";
					cmd += "^FO35,35^A1N,28,28^FD품목번호^FS";
					cmd += "^FO152,20^GB648,63,3^FS";
					cmd += "^FO160,35^A1N,30,30^FD" + ps.data[i][0] + "^FS";
					cmd += "^FO30,80^GB125,63,3^FS";
					cmd += "^FO60,100^A1N,30,30^FD품명^FS";
					cmd += "^FO152,80^GB648,63,3^FS";
					cmd += "^FO160,100^A1N,30,30^FD" + ps.data[i][1] + "^FS";

					cmd += "^FO30,140^GB125,63,3^FS";
					cmd += "^FO48,160^A1N,30,30^FD입고일^FS";
					cmd += "^FO152,140^GB155,63,3^FS";
					cmd += "^FO160,165^A1N,22,25^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO304,140^GB135,63,3^FS";
					cmd += "^FO308,160^A1N,30,30^FD합부판정^FS";
					cmd += "^FO436,140^GB105,63,3^FS";
					cmd += "^FO445,160^A1N,28,28^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO539,140^GB105,63,3^FS";
					cmd += "^FO560,160^A1N,28,28^FD창고^FS";
					cmd += "^FO642,140^GB158,63,3^FS";
					cmd += "^FO660,160^A1N,28,28^FD" + ps.data[i][4] + "^FS";

					cmd += "^FO30,200^GB125,63,3^FS";
					cmd += "^FO35,220^A1N,28,28^FD입고수량^FS";
					cmd += "^FO152,200^GB155,63,3^FS";
					cmd += "^FO160,220^A1N,25,25^FD" + ps.data[i][5] + "^FS";
					cmd += "^FO304,200^GB135,63,3^FS";
					cmd += "^FO308,220^A1N,30,30^FD업체로트^FS";
					cmd += "^FO436,200^GB105,63,3^FS";
					cmd += "^FO445,222^A1N,21,19^FD" + ps.data[i][6] + "^FS";
					cmd += "^FO539,200^GB105,63,3^FS";
					cmd += "^FO550,220^A1N,28,28^FD업체명^FS";
					cmd += "^FO642,200^GB158,63,3^FS";
					cmd += "^FO650,220^A1N,23,22^FD" + ps.data[i][7] + "^FS";

					cmd += "^FO30,260^GB770,143,3^FS";
					cmd += "^FO170,280^BCN,80,Y,N,N^FD" + ps.data[i][8] + "^FS";
					cmd += "^XZ";
					cmd += "^XA^JB^XZ";
					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
				}

				if (result == false)
				{
					failCount++;
				}
			}

			return failCount;
		}

		// 자재 라벨
		private int MaterialLabel_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{AY;+04,0|}";
					cmd += "{AX;-020,+000,+00|}";
					cmd += "{C|}";

					//행
					cmd += "{LC;0010,0035,0980,0110,1,5|}";
					cmd += "{LC;0010,0035,0980,0180,1,5|}";
					cmd += "{LC;0010,0035,0980,0250,1,5|}";
					cmd += "{LC;0010,0035,0980,0320,1,5|}";
					cmd += "{LC;0010,0035,0980,0485,1,5|}";

					//열
					cmd += "{LC;0155,0035,0155,0320,0,5|}";
					cmd += "{LC;0335,0180,0335,0320,0,5|}";
					cmd += "{LC;0490,0180,0490,0320,0,5|}";
					cmd += "{LC;0640,0180,0640,0320,0,5|}";
					cmd += "{LC;0795,0180,0795,0320,0,5|}";

					//데이터
					cmd += "{PV23;0015,0090,0040,0040,01,0,00,B=" + ps.column[i][0] + "|}";
					cmd += "{PV23;0165,0090,0040,0040,01,0,00,B=" + ps.data[i][9] + "|}";
					cmd += "{PV23;0500,0090,0040,0040,01,0,00,B=" + ps.column[i][1] + "|}";
					cmd += "{PV23;0670,0090,0040,0040,01,0,00,B=" + ps.data[i][0] + "|}";

					cmd += "{PV23;0045,0160,0040,0040,01,0,00,B=" + ps.column[i][2] + "|}";
					cmd += "{PV23;0170,0160,0040,0040,01,0,00,B=" + ps.data[i][1] + "|}";

					cmd += "{PV23;0015,0230,0040,0040,01,0,00,B=" + ps.column[i][3] + "|}";
					cmd += "{PV23;0170,0230,0035,0035,01,0,00,B=" + ps.data[i][2] + "|}";
					cmd += "{PV23;0345,0230,0040,0040,01,0,00,B=" + ps.column[i][4] + "|}";
					cmd += "{PV23;0517,0230,0040,0040,01,0,00,B=" + ps.data[i][3] + "|}";
					cmd += "{PV23;0650,0230,0032,0032,01,0,00,B=" + ps.column[i][5] + "|}";
					cmd += "{PV23;0810,0230,0035,0035,01,0,00,B=" + ps.data[i][4] + "|}";

					cmd += "{PV23;0015,0300,0040,0040,01,0,00,B=" + ps.column[i][6] + "|}";
					cmd += "{PV23;0170,0300,0035,0035,01,0,00,B=" + ps.data[i][5] + "|}";
					cmd += "{PV23;0345,0300,0040,0040,01,0,00,B=" + ps.column[i][7] + "|}";
					cmd += "{PV23;0505,0300,0035,0035,01,0,00,B=" + ps.data[i][6] + "|}";
					cmd += "{PV23;0650,0300,0040,0040,01,0,00,B=" + ps.column[i][8] + "|}";
					cmd += "{PV23;0810,0300,0035,0035,01,0,00,B=" + ps.data[i][7] + "|}";

					cmd += "{XB03;0160,0350,9,3,03,0,0100,+0000000001,000,1,00|}";
					cmd += "{RB03;" + ps.data[i][8] + "|}";
					cmd += "{XS;I,0001,0002C4001|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^CI28";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					cmd += "^FO30,20^GB125,63,3^FS";
					cmd += "^FO60,40^A1N,28,28^FD" + ps.column[i][0] + "^FS";
					cmd += "^FO152,20^GB155,63,3^FS";
					cmd += "^FO157,40^A1N,28,28^FD" + ps.data[i][9] + "^FS";
					cmd += "^FO304,20^GB135,63,3^FS";
					cmd += "^FO318,40^A1N,28,28^FD" + ps.column[i][1] + "^FS";
					cmd += "^FO436,20^GB365,63,3^FS";
					cmd += "^FO450,35^A1N,30,30^FD" + ps.data[i][0] + "^FS";

					cmd += "^FO30,80^GB125,63,3^FS";
					cmd += "^FO60,100^A1N,30,30^FD" + ps.column[i][2] + "^FS";
					cmd += "^FO152,80^GB648,63,3^FS";
					cmd += "^FO160,100^A1N,30,30^FD" + ps.data[i][1] + "^FS";

					cmd += "^FO30,140^GB125,63,3^FS";
					cmd += "^FO35,160^A1N,28,28^FD" + ps.column[i][3] + "^FS";
					cmd += "^FO152,140^GB155,63,3^FS";
					cmd += "^FO160,165^A1N,22,25^FD" + ps.data[i][2] + "^FS";
					cmd += "^FO304,140^GB135,63,3^FS";
					cmd += "^FO308,160^A1N,30,30^FD" + ps.column[i][4] + "^FS";
					cmd += "^FO436,140^GB105,63,3^FS";
					cmd += "^FO445,160^A1N,28,28^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO539,140^GB125,63,3^FS";
					cmd += "^FO548,160^A1N,28,28^FD" + ps.column[i][5] + "^FS";
					cmd += "^FO662,140^GB138,63,3^FS";
					cmd += "^FO670,160^A1N,25,25^FD" + ps.data[i][4] + "^FS";

					cmd += "^FO30,200^GB125,63,3^FS";
					cmd += "^FO35,220^A1N,28,28^FD" + ps.column[i][6] + "^FS";
					cmd += "^FO152,200^GB155,63,3^FS";
					cmd += "^FO160,220^A1N,25,25^FD" + ps.data[i][5] + "^FS";
					cmd += "^FO304,200^GB135,63,3^FS";
					cmd += "^FO308,220^A1N,30,30^FD" + ps.column[i][7] + "^FS";
					cmd += "^FO436,200^GB105,63,3^FS";
					cmd += "^FO445,222^A1N,21,19^FD" + ps.data[i][6] + "^FS";
					cmd += "^FO539,200^GB105,63,3^FS";
					cmd += "^FO550,220^A1N,28,28^FD" + ps.column[i][8] + "^FS";
					cmd += "^FO642,200^GB158,63,3^FS";
					cmd += "^FO650,220^A1N,25,25^FD" + ps.data[i][7] + "^FS";

					cmd += "^FO30,260^GB770,143,3^FS";
					cmd += "^FO170,280^BCN,80,Y,N,N^FD" + ps.data[i][8] + "^FS";
					cmd += "^XZ";
					cmd += "^XA^JB^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;

					}
				}
			}

			return failCount;
		}

		// 반제품/완제품 라벨
		private int ProductLabel_Code(PrintString ps)
		{
			bool result = true;
			int failCount = 0;

			if (ps.printerCode == "T")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "{D0520,0980,0500|}";
					cmd += "{AY;+04,0|}";
					cmd += "{AX;-020,+000,+00|}";
					cmd += "{C|}";

					//행
					cmd += "{LC;0010,0035,0980,0110,1,5|}";
					cmd += "{LC;0010,0035,0980,0180,1,5|}";
					cmd += "{LC;0010,0035,0980,0250,1,5|}";
					cmd += "{LC;0010,0035,0980,0320,1,5|}";
					cmd += "{LC;0010,0035,0980,0485,1,5|}";
					cmd += "{LC;0659,0184,0980,0380,1,5|}";

					//열
					cmd += "{LC;0155,0035,0155,0320,0,5|}";
					cmd += "{LC;0655,0035,0655,0110,0,5|}";
					cmd += "{LC;0480,0035,0480,0110,0,5|}";
					cmd += "{LC;0480,0180,0480,0320,0,5|}";
					cmd += "{LC;0655,0180,0655,0485,0,5|}";

					//데이터
					cmd += "{PV23;0015,0090,0040,0040,01,0,00,B=" + ps.column[i][0] + "|}";
					cmd += "{PV23;0165,0090,0040,0040,01,0,00,B=" + ps.data[i][0] + "|}";
					cmd += "{PV23;0500,0090,0040,0040,01,0,00,B=" + ps.column[i][1] + "|}";
					cmd += "{PV23;0670,0090,0040,0040,01,0,00,B=" + ps.data[i][1] + "|}";
					cmd += "{PV23;0015,0160,0040,0040,01,0,00,B=" + ps.column[i][2] + "|}";
					cmd += "{PV23;0165,0160,0040,0040,01,0,00,B=" + ps.data[i][2] + "|}";
					cmd += "{PV23;0015,0230,0040,0040,01,0,00,B=" + ps.column[i][3] + "|}";
					cmd += "{PV23;0165,0230,0040,0040,01,0,00,B=" + ps.data[i][3] + "|}";
					cmd += "{PV23;0500,0230,0040,0040,01,0,00,B=" + ps.column[i][4] + "|}";
					cmd += "{PV23;0670,0230,0040,0040,01,0,00,B=" + ps.data[i][4] + "|}";
					cmd += "{PV23;0015,0300,0040,0040,01,0,00,B=" + ps.column[i][5] + "|}";
					cmd += "{PV23;0165,0300,0040,0040,01,0,00,B=" + ps.data[i][5] + "|}";
					cmd += "{PV23;0500,0300,0040,0040,01,0,00,B=" + ps.column[i][6] + "|}";
					cmd += "{PV23;0670,0300,0040,0040,01,0,00,B=" + ps.data[i][6] + "|}";
					cmd += "{PV23;0710,0365,0040,0040,01,0,00,B=" + ps.column[i][7] + "|}";
					cmd += "{PV23;0770,0450,0040,0040,01,0,00,B=" + ps.data[i][7] + "|}";
					cmd += "{XB03;0120,0350,9,3,02,0,0100,+0000000001,000,1,00|}";
					cmd += "{RB03;" + ps.data[i][8] + "|}";
					cmd += "{XS;I,0001,0002C4001|}";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "utf-8");

					if (result == false)
					{
						failCount++;

					}
				}
			}
			else if (ps.printerCode == "G")
			{
				for (int i = 0; i < ps.printCnt; i++)
				{
					string cmd = "";
					cmd += "^XA";
					cmd += "^CI28";
					cmd += "^SEE:UHANGUL.DAT^FS";
					cmd += "^CW1,E:KFONT3.FNT^CI26^FS";

					cmd += "^FO30,20^GB125,63,3^FS";
					cmd += "^FO60,40^A1N,28,28^FD" + ps.column[i][0] + "^FS";
					cmd += "^FO152,20^GB155,63,3^FS";
					cmd += "^FO157,40^A1N,28,28^FD" + ps.data[i][0] + "^FS";
					cmd += "^FO304,20^GB135,63,3^FS";
					cmd += "^FO318,40^A1N,28,28^FD" + ps.column[i][1] + "^FS";
					cmd += "^FO436,20^GB365,63,3^FS";
					cmd += "^FO450,40^A1N,30,30^FD" + ps.data[i][1] + "^FS";

					cmd += "^FO30,80^GB125,63,3^FS";
					cmd += "^FO60,100^A1N,30,30^FD" + ps.column[i][2] + "^FS";
					cmd += "^FO152,80^GB648,63,3^FS";
					cmd += "^FO160,100^A1N,30,30^FD" + ps.data[i][2] + "^FS";

					cmd += "^FO30,140^GB125,63,3^FS";
					cmd += "^FO35,160^A1N,28,28^FD" + ps.column[i][3] + "^FS";
					cmd += "^FO152,140^G256,63,3^FS";
					cmd += "^FO160,165^A1N,22,25^FD" + ps.data[i][3] + "^FS";
					cmd += "^FO400,140^GB135,63,3^FS";
					cmd += "^FO405,160^A1N,30,30^FD" + ps.column[i][4] + "^FS";
					cmd += "^FO532,140^GB268,63,3^FS";
					cmd += "^FO585,160^A1N,30,30^FD" + ps.data[i][4] + "^FS";

					cmd += "^FO30,200^GB125,63,3^FS";
					cmd += "^FO40,220^A1N,28,28^FD" + ps.column[i][5] + "^FS";
					cmd += "^FO152,200^GB251,63,3^FS";
					cmd += "^FO160,220^A1N,25,25^FD" + ps.data[i][5] + "^FS";
					cmd += "^FO400,200^GB135,63,3^FS";
					cmd += "^FO415,220^A1N,30,30^FD" + ps.column[i][6] + "^FS";
					cmd += "^FO532,200^GB268,63,3^FS";
					cmd += "^FO585,222^A1N,30,30^FD" + ps.data[i][6] + "^FS";

					cmd += "^FO30,260^GB511,143,3^FS";
					cmd += "^FO50,280^BCN,80,Y,N,N^FD" + ps.data[i][8] + "^FS";
					cmd += "^FO539,260^GB261,53,3^FS";
					cmd += "^FO585,275^A1N,28,28^FD" + ps.column[i][7] + "^FS";
					cmd += "^FO539,310^GB261,93,3^FS";
					cmd += "^FO620,340^A1N,28,28^FD" + ps.data[i][7] + "^FS";
					cmd += "^XZ";
					cmd += "^XA^JB^XZ";

					result = RawPrinterHelper.SendStringToPrinter(ps.printerName, cmd, "euc-kr");
					if (result == false)
					{
						failCount++;
					}
				}
			}

			return failCount;
		}
	}
}
